# sicarx-mcp — Referencia de la API (para sesiones de Claude)

> Este documento es la referencia de trabajo del servidor MCP `sicarx-mcp`, que expone la API
> privada (no oficial, reverse-engineered) de SICAR-X para la cuenta de **Quesos y mas quesos**
> (empresa `5f5417b1-d859-436b-ad83-07b8effe2dfb`, sucursal **AGUSTIN MELGAR**, `branchId 176665`).
> El código fuente vive en `src/index.js` (mismo directorio). Este archivo documenta CADA
> herramienta (`server.tool(...)`) tal como quedó confirmada contra la cuenta real, para que otra
> sesión de Claude no tenga que repetir la investigación desde cero.
>
> Última revisión completa: **2026-09-02**.
>
> El servidor corre como proceso MCP local en la Mac del usuario (registrado en Claude Desktop),
> y se alcanza desde una sesión en la nube con el prefijo de herramientas
> `mcp__remote-devices__sicarx__<nombre>`. Sin la Mac conectada (link de dispositivo activo), estas
> herramientas no están disponibles.

## Leyenda de estado

- ✅ **Confirmado** — probado en vivo contra la cuenta real, funciona tal como está documentado.
- ⚠️ **No confirmado / incierto** — la forma del endpoint es la mejor hipótesis de la ingeniería
  inversa, pero no se probó a fondo (o solo parcialmente) contra datos reales. Usar con cautela,
  sobre todo si escribe datos.
- ❌ **Roto / no funciona** — se probó y falla de forma consistente. Se documenta el error exacto
  y, si existe, la alternativa que sí funciona.
- ✍️ **Escritura** — modifica datos reales de la cuenta. Todas estas herramientas requieren
  `confirm: true` explícito como salvaguarda; nunca mandes `confirm: true` sin que el usuario haya
  aprobado los datos exactos primero.

---

## 0. Sesión y autenticación

El login es automático (lazy) la primera vez que cualquier herramienta necesita un token — no hace
falta llamar nada manualmente antes. `sicarx_select_branch` sólo hace falta si quieres cambiar de
sucursal o forzar un re-login.

### `sicarx_whoami` ✅
Muestra el estado de la sesión: si hay token de cuenta/sucursal, cuándo expiran, claims del JWT y
qué `branchId` está activo. Sin parámetros. Útil para diagnosticar problemas de login.

### `sicarx_list_companies` ✅
Lista las empresas a las que tiene acceso la cuenta (token de nivel "account"). Sin parámetros.
Para esta cuenta devuelve una sola empresa: "Quesos y mas quesos".

### `sicarx_list_branches` ✅
Lista las sucursales de una empresa. Param opcional `companyUuid`. Para esta cuenta: una sola
sucursal, `branchId 176665` ("AGUSTIN MELGAR").

### `sicarx_select_branch` ✅
Inicia sesión de sucursal con el `branchId` indicado (`z.string()`, obligatorio) y deja ese token
activo para el resto de herramientas. Normalmente no hace falta llamarla si `SICARX_BRANCH_ID` ya
está en `.env` — el login de sucursal es automático.

---

## 1. Catálogo de productos

### `sicarx_list_products` ⚠️
`POST product/v1/product/list`. Lista/pagina el catálogo. **Su filtro `search` NO filtra
server-side de forma confiable** (comportamiento observado en sesiones anteriores) — para buscar
productos por texto usa mejor **`sicarx_search_products`**. Params: `search, limit, offset,
departmentUuid, categoryUuid, extraBody` (objeto crudo adicional).

### `sicarx_search_products` ✅
`POST search/v1/search/product?from=&size=` — búsqueda REAL server-side por texto (a diferencia de
`sicarx_list_products`). Body `{description: search, priceListId?, type?}`. **`size` tiene un
mínimo de 10** — el servidor rechaza valores menores con `{"code":2,"message":"items with value 5
must not be less than 10"}`. Devuelve resultados ricos: uuid, description, imageUrl, prices,
categoryUuid, departmentUuid, type, sku, bulk, autoWeigh, salesUnitUuid, lot, series, saleable,
highlights[], score.

### `sicarx_get_product` ✅
`GET product/v1/product/{uuid}`. Detalle completo de un producto (sku, description, claveSat,
salesUnitUuid, departmentUuid, categoryUuid, saleable, bulk, autoWeigh, favorite, avgPurchasePrice,
minProfitPercentage, prices, etc.). Único param: `uuid`.

### `sicarx_check_sku` ✅
`POST product/v1/product/checkSku`, body = el SKU como **texto plano** (`Content-Type:
text/plain`, NO JSON). Devuelve `true`/`false` si el SKU ya existe. Útil antes de dar de alta un
producto.

### `sicarx_list_deleted_products` ✅
`GET product/v1/deleted/list?offset=&items=`. Lista productos borrados (para consultar o
restaurar). Devuelve el mismo shape que un producto normal.

### `sicarx_get_deleted_product` ✅
`GET product/v1/deleted/{uuid}`. Detalle de un producto borrado específico.

### `sicarx_list_departments` ✅ / `sicarx_list_categories` ✅ / `sicarx_list_units` ✅
`GET department/v1/department/list`, `GET department/v1/category/list`, `GET unit/v1/unit/list`.
Sin parámetros. Necesarios para armar `departmentUuid`/`categoryUuid`/`salesUnitUuid` al crear un
producto.

### `sicarx_create_product` ⚠️✍️
`PUT product/v1/product`. Da de alta un producto nuevo. Params: `description, sku, departmentUuid,
categoryUuid, salesUnitUuid` (obligatorios), más `price/priceListUuid/prices, bulk, autoWeigh,
saleable, type, claveSat, extraBody`. Requiere `confirm: true`. La forma general del body se dedujo
del código fuente pero **no se probó a fondo creando un producto real** — revisa un producto
similar con `sicarx_get_product` como referencia antes de usarla.

### `sicarx_edit_product` ⚠️✍️
`PATCH product/v1/product/{uuid}`, body = sólo los campos a cambiar (`fields`, objeto libre).
Requiere `confirm: true`. Misma incertidumbre que `sicarx_create_product` sobre qué campos exactos
acepta el PATCH.

### Imágenes de producto — `sicarx_upload_product_image` ✅✍️
Flujo de 2 pasos (confirmado y usado en producción varias veces esta sesión, subiendo ~9 imágenes
reales sin fallos):
1. `POST product/v1/image/signUrl {productUuid, imageUuid, contentType, contentLength, selected}`
   → devuelve una URL firmada de S3 (string).
2. `PUT` directo a esa URL firmada (**sin** el `Authorization` de SICAR-X — es S3, no la API), body
   = bytes crudos del archivo, headers EXACTOS (van incluidos en la firma):
   `Content-Type: <contentType>`, `x-amz-meta-content-id: <contentId de la empresa>`,
   `x-amz-meta-product-id: <productUuid>`, `x-amz-meta-selected: "true"|"false"`.
   El `contentId` sale del claim `x` del companyToken (ver `sicarx_whoami`).

No hace falta ningún paso de confirmación posterior — el backend procesa el objeto S3 usando esos
metadatos. `imagePath` debe ser una ruta **local, accesible desde donde corre el proceso MCP**
(la Mac del usuario), no una ruta de la sesión en la nube. Requiere `confirm: true`.

### `sicarx_select_product_image` ⚠️
`POST product/v1/image/select/{productUuid}/{imageUuid}` (body vacío). Marca una imagen YA SUBIDA
como la principal. No probada a fondo esta sesión (no hizo falta — `sicarx_upload_product_image`
ya incluye `selected`).

---

## 2. Stock e inventario

### `sicarx_get_stock` ✅
Consulta existencias de un producto. `productUuid` (obligatorio), `detail` (bool, default false),
`branch` (sólo aplica con `detail=true`).
- `detail=false` → `GET stock/v1/stock/info/{uuid}` (resumen: disponible, si maneja lotes/series).
- `detail=true` → `GET stock/v1/stock/{uuid}/all` (detalle por almacén).

### `sicarx_list_warehouses` ✅
`GET stock/v1/warehouse/list`. Para esta cuenta devuelve **vacío (204)** — sólo maneja un almacén
implícito, así que las demás herramientas de stock no necesitan `warehouseId`.

### `sicarx_list_lots` ✅
`GET stock/v1/lot/list/{productUuid}` (o `/{warehouseUuid}/{productUuid}` si se pasa
`warehouseUuid`). Para un producto que no maneja lotes devuelve array vacío sin error.

### `sicarx_stock_history` ✅ (corregido 2026-09-02)
`POST stock-reports/v1/history`. Historial/kardex de movimientos de stock **de TODA la sucursal**
en un rango de fechas. Params: **`from`/`until`** (fecha `YYYY-MM-DD`, ambos obligatorios — OJO,
NO son `startDate`/`endDate`, ese nombre da `{"code":2,"message":"from date is required"}`),
`productUuid` (opcional), `warehouseId` (opcional), `extra` (objeto crudo).
**⚠️ `productUuid` NO filtra server-side** — el response siempre trae TODOS los productos con
movimientos en el rango; hay que filtrar tú mismo del lado del cliente si sólo quieres uno. Cada
elemento trae `oldStock/newStock/oldAvailable/newAvailable`, tipo de movimiento
(`CREATE/SET/EGRESS/INGRESS`), folio, usuario, timestamp.

### Movimientos de inventario (ajustes manuales)

El flujo real (usado por la app) es de 3 pasos: **crear movimiento (vacío) → agregar
detalle (productos+cantidades) → aplicar**. Mientras no se aplica, NO afecta stock real.

**Enum `MovementType` real** (confirmado en el código fuente Y probando contra la cuenta real):
`0=INGRESS, 1=EGRESS, 2=FREE`. Ojo: hay una tabla de traducción de UI (`h={2:INGRESS,3:EGRESS,
4:FREE}`) que **NO son los valores reales del enum** — es sólo un mapeo interno de un selector de
la interfaz. `type=4` de hecho es inválido ("Invalid type value"); `type=3` sí es aceptado por el
backend pero **no es EGRESS del enum real** — se comporta igual que `type=1` en las pruebas
(resta contra `currentStock`), pero su semántica exacta no está 100% aclarada — **no lo uses a
ciegas asumiendo que es EGRESS**, usa `type=1` o mejor `type=2` (FREE) que es el que usa
`sicarx_adjust_inventory`.

- **`type=2` (FREE)**: al aplicar, el stock queda **exactamente igual a `quantity`** (set
  absoluto — sube o baja sin restricción). `currentStock` NO se usa en el cálculo, sólo queda de
  referencia/auditoría. Es el mecanismo que usa `sicarx_adjust_inventory`.
- **`type=1` (EGRESS, y el `type=3` observado con igual comportamiento)**: `newStock =
  currentStock_enviado − quantity_enviado`. El backend valida que el resultado sea una baja real
  respecto al stock REAL del sistema (no sólo respecto al `currentStock` que uno mande) — si no
  baja, rechaza con `"contains negative quantity"`.
- **`type=0` (INGRESS)**: no se probó a fondo (se creó un movimiento pero no se le agregaron
  detalles ni se aplicó).

#### `sicarx_create_movement` ✅✍️
`PUT movement/v1/movement`, body `{uuid (autogenerado), type, description?, title?, warehouse?,
priceListUuid}`. `priceListUuid` se resuelve automático (cacheado en memoria) vía
`getDefaultPriceListUuid()` si no se pasa. No afecta stock por sí solo.

#### `sicarx_add_movement_detail` ✅✍️
`PUT movement/v1/movement/detail/{movementUuid}`, body = array de `{uuid: productUuid, quantity,
currentStock?}`. Sigue sin afectar stock real hasta aplicar.

#### `sicarx_apply_movement` ✅✍️ ⚠️ escribe stock real
`POST movement/v1/movement/apply` — **este es el paso que sí modifica el stock real**. **Gotcha
confirmado**: el body es el uuid del movimiento como **string JSON crudo** (`JSON.stringify(uuid)`,
ej. `"abc-123"` con comillas), NO un objeto `{uuid: ...}`. Axios manda
`application/x-www-form-urlencoded` por default para bodies tipo string, y SICAR-X lo rechaza con
415 — hay que forzar `headers: {"Content-Type": "application/json"}`. No es reversible con un
"deshacer" — para revertir hay que crear otro movimiento en sentido contrario. Requiere
`confirm: true`.

#### `sicarx_delete_movement` ⚠️
`DELETE movement/v1/movement/{uuid}`. Sólo funciona (probablemente) con movimientos NO aplicados
todavía. Si ya se aplicó, borrar el movimiento **probablemente no revierte** el cambio de stock
(no confirmado).

#### `sicarx_get_movement` ✅
`GET movement/v1/movement/{uuid}`. Detalle de un movimiento (útil para revisar antes de aplicar, o
auditar uno ya aplicado).

#### `sicarx_list_movements` ✅
`POST movement/v1/movement/list?offset=&size=`, body `{initialDate, endDate, ...extraBody}`
(`initialDate`/`endDate` obligatorios, formato ISO `2026-08-01T00:00:00`). Confirmado en vivo
2026-09-02: devuelve el historial real de ajustes de esta cuenta (uuid, title, description, type,
total, timestamp, identifier/folio, quién aplicó, etc.).

#### `sicarx_adjust_inventory` ✅✍️ (herramienta de alto nivel, recomendada)
Hace los 3 pasos de un jalón (crear tipo FREE → agregar detalle → aplicar) para dejar el stock de
uno o más productos en la cantidad **EXACTA/ABSOLUTA** indicada — confirmado empíricamente: es un
**set directo**, no una suma ni resta, sin importar si sube o baja respecto al stock anterior. Si
no se manda `currentStock` por producto, lo consulta automático antes (sólo para auditoría, no
afecta el cálculo). Param `apply` (default `true`) — si `false`, crea+agrega detalle pero NO
aplica, útil para revisar antes del paso final. Requiere `confirm: true`. **Esta es la forma
recomendada** de hacer un ajuste de inventario en vez de encadenar las 3 herramientas de bajo nivel
a mano.

---

## 3. Ventas y compras

### ❌🚫 `sicarx_list_sales` / `sicarx_get_sale` / `sicarx_list_purchases` / `sicarx_get_purchase` — DESHABILITADAS
**Confirmado roto el 2026-09-02**: `sales-queries/v1/list`, `sales-queries/v1/generated/{id}`,
`purchases-queries/v1/list`, y `purchases-queries/v1/generated/signedUrl/{id}` devuelven
**consistentemente HTTP 503** `{"status":503,"error":"Not Found","source":"gateway","retry":false}`
sin importar los parámetros probados (con o sin fechas, con uuid real o inventado). Parece un
problema de aprovisionamiento del gateway para esta cuenta específica, no un bug del body/query
armado aquí — la estructura de la ruta coincide con el patrón de otros endpoints `-queries` que sí
funcionan.

**Desde el 2026-09-02 estas 4 herramientas están deshabilitadas en el código** (`.disable()` justo
antes de `main()` en `src/index.js`) — siguen registradas y documentadas, pero **no aparecen en la
lista de herramientas del MCP** ni se pueden invocar (`"Tool X disabled"`), en vez de quedar
visibles fallando siempre. Si algún día SICAR-X arregla el gateway, hay que confirmarlo primero con
`sicarx_raw_request` y luego quitar/comentar el bloque `.disable()` al final de `src/index.js`.

### ✅ ALTERNATIVA QUE SÍ FUNCIONA: `sicarx_report` con `report='sales'` o `report='purchases'`
**Confirmado en vivo el 2026-09-02** — usa `sicarx_report` (sección 5) para todo lo relacionado a
listar ventas/compras:
```
sicarx_report({
  report: "sales",        // o "purchases"
  variant: "data",
  params: {
    startDate: "2026-08-01", endDate: "2026-09-02",
    timeZone: "America/Chihuahua",
    taxFilter: "WITH_TAXES"   // obligatorio para sales/purchases
  }
})
```
Devuelve una lista rica: `uuid, id, folio, creationDate, agentName, sellerName, totalDoc, discount,
total, type (SALE|SALE_REFUND), warehouse, payment, branchName`, etc. También existe
`variant: "summary"` para sólo el resumen (`{registries, discount, total, discountPercentage}`).

**⚠️ Gotcha de paginación**: NO mandes `params.offset: 0` explícito en la primera página — el
backend intenta decodificarlo como cursor base64 (usa BigQuery internamente) y tira
`500 Internal Server Error` (`IllegalArgumentException: Input byte[] should at least have 2 bytes
for base64 bytes`). **Omite `offset` por completo** para la primera página. `limit` tiene mínimo
10 en `variant='data'`.

---

## 4. Clientes y proveedores (agentes)

### `sicarx_list_agents` ✅ (corregido dos veces, confirmado por introspección GraphQL 2026-09-02)
`POST agent/v1/catalogue/graphToSpecification` — GraphQL, query `agentsWithCredit`. A diferencia
del catálogo de productos, **sí soporta búsqueda server-side real por nombre** (`search`).
Params: `agentType` (número: **1=CLIENT, 2=SUPPLIER** — confirmado por introspección del schema,
NO es un string enum), `search` (default `""`), `status` (default `1`), `offset` (¡ojo!: **string**
tanto en el argumento como en el campo de respuesta, aunque parezca numérico — se manda entre
comillas en la query), `size` (default `20`), `withCredit` (bool).

La respuesta viene envuelta en `PageAgentWithCred {hasNext, offset, elements: [AgentWithCredit]}` —
NO son campos planos. Campos confirmados de `AgentWithCredit` (por introspección): `agentCredit,
uuid, contentId(Long), branchId(Long), name, alias, priceNumber(Int), type(Int, 1=CLIENT/
2=SUPPLIER), key, imageUrl, curp, emails([String]), phoneNumbers([Phone]), comment, birthday(Date),
creditLimit(BigDecimal), creditDays(Int), status(Int), purchased(Boolean), accountId, externalId,
deliveryIntervalDays(Int), created(DateTime), userCreatorUuid, modified(DateTime),
userModifierUuid`. Para esta cuenta actualmente devuelve 0 agentes (no hay clientes/proveedores
dados de alta todavía en SICAR-X).

### `sicarx_get_agent` ✅
`GET agent/v1/agent/{uuid}/{agentType}` — REST normal (no GraphQL). `agentType` aquí es
**numérico** (1=CLIENT, 2=SUPPLIER), a diferencia de `sicarx_get_agent_credit` que usa el string.
Confirmado: contra un uuid inexistente devuelve `404` limpio.

### `sicarx_get_agent_credit` ✅
`GET agent/v1/credit/list/agent/{CLIENT|SUPPLIER}/{agentId}` — aquí `agentType` SÍ es un **string
enum** (`"CLIENT"`/`"SUPPLIER"`, default `"SUPPLIER"`), a diferencia de `sicarx_get_agent`.
Confirmado: 404 limpio contra un `agentId` inexistente.

### `sicarx_create_agent` ⚠️✍️
`POST agent/v1/agent`, body = `fields` libre. Los NOMBRES de campo están confirmados por
introspección GraphQL (ver arriba, mismo shape que `AgentWithCredit`), pero **no está confirmado
cuáles son obligatorios para crear** — no se ha probado creando un agente real todavía (no había
necesidad — la cuenta no tiene proveedores dados de alta en SICAR-X). Requiere `confirm: true`.

### `sicarx_edit_agent` ⚠️✍️
`PATCH agent/v1/agent/{uuid}/{agentType}` (numérico), body = sólo los campos a cambiar. Misma
incertidumbre que `sicarx_create_agent`. Requiere `confirm: true`.

### `sicarx_assign_agent_credit` ⚠️✍️
`POST agent/v1/credit/list/agent`, body `{agentType (string CLIENT|SUPPLIER), agentId,
creditLimit, creditDays, blockCreditIfOverdue}`. No probado contra datos reales. Requiere
`confirm: true`.

---

## 5. Reportes (`sicarx_report` / `sicarx_list_reports`)

Todos los reportes cuelgan de `sales-reports/v1/`. Usa `sicarx_list_reports` (sin params) para ver
la lista completa con la documentación de parámetros de cada uno — está toda en el objeto `REPORTS`
del código fuente. Reportes disponibles: `sales, salesProfit, salesByAgent,
salesByDepartmentWithTaxes/WithoutTaxes, salesByUserWithTaxes/WithoutTaxes,
ordersByUserWithTaxes/WithoutTaxes, products, refundsWithTaxes/WithoutTaxes, orders, purchases,
purchasesBySupplier, purchasesByProducts, cashMovements, cfdiExport, cfdiCreditNoteExport,
agentCreditsReport, agentPaymentsReport, kardex`.

`sicarx_report({report, variant, params})`:
- `variant='data'` → JSON normal. ✅ Confirmado para `sales` y `purchases` (ver sección 3).
- `variant='summary'` → sólo si el reporte tiene `summaryPath`. ✅ Confirmado para `sales` y
  `purchases` (`{registries, discount, total, discountPercentage}`).
- `variant='export'` → descarga Excel/CSV/PDF a `~/Downloads/sicarx-reports` en la máquina donde
  corre el proceso MCP (la Mac del usuario) y devuelve la ruta del archivo, no el JSON. Reportes
  marcados `blob: true` (como `kardex`, `cfdiExport`, `cfdiCreditNoteExport`) **sólo** existen como
  export, no tienen variante `data`.
- `variant='nextPage'` → sólo `cashMovements` la soporta (paginación por offset, distinta al
  problema de cursor de `variant='data'`).

**Gotchas confirmados (2026-09-02)**:
- `taxFilter` es **obligatorio** para `report='sales'` (y probablemente `purchases`) — sin él da
  `400 "Required parameter 'taxFilter' is not present"`. Valor confirmado válido: `"WITH_TAXES"`.
- En `variant='data'`, **no mandes `offset: 0`** en la primera página (ver sección 3 para el error
  exacto) — omite el parámetro. `limit` mínimo 10.

---

## 6. Caja registradora y formas de pago

### `sicarx_get_payment_options` ✅
`GET settings/v1/paymentOption/list/byBranch`. Enum de `paymentId` confirmado (cruzado contra el
código fuente, objeto `I` en `CashRegisterMovs-*.js`): `1=CASH, 2=DEBIT_CARD, 3=CREDIT_CARD,
4=ELECTRONIC_TRANSFER, 5=CHECK, 6=GROCERY_VOUCHER`.

### `sicarx_list_cash_registers` ✅ / `sicarx_get_cash_register` ✅
`GET cashregister/v1/queries/list` y `GET cashregister/v1/queries/{uuid}`. Para esta cuenta hay una
sola caja: `{folio:1, name:"Agustin Melgar", uuid:"38989983-ad59-4b63-bb6e-057da442a5a1",
status:"ENABLED", inUse:true}`.

### `sicarx_cash_register_balance_list` ✅ (corregido 2026-09-02)
`GET cashregister/v1/balancing-queries/list`. **La ruta correcta NO es
`/balancing-queries/balance/list`** (eso da `404 "No static resource
balancing-queries/balance"`) — es `/balancing-queries/list` directo. Params **obligatorios**:
`startDate`, `endDate` (YYYY-MM-DD), `timeZone` (default `America/Chihuahua` en la herramienta).
Sin cortes en el rango devuelve `204` vacío.

### `sicarx_cash_register_transaction` ⚠️⚠️✍️ — NO USAR CON DINERO REAL SIN PROBAR PRIMERO
`POST cashregister/v1/cashRegister/transaction`. **El valor exacto que espera `type` para
distinguir ENTRADA vs. SALIDA de efectivo NO se pudo confirmar** — es un enum interno
(`Ee.INCOME`/`Ee.EXPENSE`) cuyo valor numérico/string real no se pudo leer del código minificado
pese a grepping dirigido. Antes de usar con montos reales, probar con un monto pequeño y **verificar
en la app** que quedó registrado como se esperaba. Requiere `confirm: true`.

### `sicarx_cash_register_unlock` ⚠️✍️
`POST cashregister/v1/cashRegister/unlock`, body = el uuid de la caja como texto plano. No probado
a fondo. Requiere `confirm: true`.

### `sicarx_close_cash_register` ⚠️✍️ — INCOMPLETO, no confiar para un corte real
`POST cashregister/v1/cashRegister/close`. **Requiere `lockUuid`**, un valor que la app
normalmente saca de un candado local (localStorage) que este servidor MCP no tiene — probablemente
haya que obtenerlo bloqueando la caja desde la app primero, o investigar más. `counted` es un
objeto `{"<isoMoneda>.<paymentOptionId>": "<monto>"}`, ej. `{"MXN.1": "1500.00"}`. Requiere
`confirm: true`. **No usar para un corte de caja real hasta resolver el origen de `lockUuid`.**

### `sicarx_create_payment_option` ⚠️✍️ / `sicarx_edit_payment_option` ⚠️✍️
`POST` / `PATCH settings/v1/paymentOption[/{id}]`, body = `fields` libre (ver
`sicarx_get_payment_options` para el shape de las existentes como referencia). No probadas contra
datos reales. Requieren `confirm: true`.

---

## 7. Otros / utilidades

### `sicarx_get_currencies` ✅
`GET settings/v1/currency/list`. Para esta cuenta: sólo MXN.

### `sicarx_list_price_lists` ✅
`GET prices/v1/priceList/list`. Para esta cuenta: una sola lista, `"A"`,
`d39ff3ff-c529-4491-aef3-5c287b2623bb`, `predetermined: true`.

### `sicarx_raw_request` ✅ (escape hatch, muy usado durante la investigación)
Hace una petición HTTP directa con el token de sesión adecuado. `method` (GET/POST/PUT/PATCH/
DELETE), `path` (debe empezar con `/`, relativo a `https://api.sicarx.com/`), `query` (objeto),
`body`, `authLevel` (`company`|`account`|`none`, default `company`), `headers`. Es la herramienta
recomendada para explorar/confirmar cualquier endpoint nuevo antes de convertirlo en una
`server.tool` dedicada — así se descubrieron y corrigieron varios de los bugs documentados arriba
(`sicarx_stock_history`, `sicarx_cash_register_balance_list`, los gotchas de `sicarx_report`).

---

## Notas generales para quien siga trabajando en este MCP

1. **Metodología recomendada para agregar/arreglar una herramienta**: usa `sicarx_raw_request`
   contra la cuenta real primero para confirmar la ruta/body/params exactos con pruebas empíricas
   (los errores 400 de SICAR-X suelen decir literalmente qué parámetro falta), y sólo después
   escribe/corrige la `server.tool` correspondiente en `src/index.js`.
2. **Todas las herramientas de escritura (✍️) requieren `confirm: true`** como salvaguarda de
   diseño — nunca lo mandes en `true` sin que el usuario haya revisado y aprobado explícitamente
   los datos exactos que se van a escribir. No hay entorno de pruebas: todo escribe en la cuenta
   real de SICAR-X del usuario.
3. **Después de editar `src/index.js`**: correr `node --check src/index.js`, mandarlo con
   `SendUserFile`, y `device_commit_files` (force:true) a
   `~/Desktop/sicarx-mcp/src/index.js` en la Mac del usuario. Si sólo se corrigió el *interior* de
   una tool ya existente (sin cambiar su nombre/schema), el fix se puede probar de inmediato vía
   `sicarx_raw_request` sin esperar un reinicio de Claude Desktop — pero el archivo se debe
   redesplegar igual para que el fix quede persistente. Si se agregó una tool **nueva** (nombre
   nuevo), Claude Desktop necesita reiniciarse para que el MCP la exponga, y luego hay que
   `RefreshMcpTools` + `ToolSearch("select:<nombre>")` desde la sesión en la nube antes de poder
   llamarla.
4. **La tarea programada del reporte diario de reabasto** ("Reporte diario de pedido — Quesos y
   mas Quesos") depende de `sicarx_get_stock`, que sólo funciona con la Mac vinculada — el vínculo
   de dispositivo para tareas programadas (`requires_local_device`) no se ha logrado aprobar
   automáticamente pese a varios intentos (recrear la tarea, reiniciar Claude Desktop); queda
   pendiente investigar por qué Claude Desktop no muestra el prompt de aprobación, o disparar el
   reporte manualmente cada mañana desde una sesión ya conectada.
