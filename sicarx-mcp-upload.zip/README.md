# sicarx-mcp

Servidor MCP **no oficial** que conecta Claude con la API privada de SICAR-X
(`https://api.sicarx.com/`), reconstruida por ingeniería inversa del cliente
de escritorio (`app.asar`). Permite a Claude autenticarse con tu cuenta,
consultar reportes (ventas, compras, caja, productos, CFDI, créditos de
agentes...) y, mediante la herramienta genérica `sicarx_raw_request`, llamar
cualquier otro endpoint descubierto en el código fuente de la app.

> ⚠️ Esto **no es un producto de SICAR Solutions**. La API es privada, no
> documentada oficialmente y puede cambiar sin aviso. Úsalo con tu propia
> cuenta/negocio y revisa los términos de servicio del proveedor antes de
> depender de esto en producción.

## Qué incluye

51 herramientas (`server.tool(...)`) en `src/index.js`, 47 activas + 4
deshabilitadas (ver abajo). **La referencia completa y al día de cada una —
qué hace, parámetros, y si está confirmada/incierta/rota — vive en
[`API.md`](./API.md), no aquí.** Este README es sólo el resumen de alto
nivel; para saber si una herramienta funciona o cómo usarla exactamente,
consulta `API.md`.

- **Login automático** (cuenta → sucursal) con re-login transparente cuando
  expira el JWT.
- `sicarx_whoami` — estado de la sesión.
- `sicarx_list_companies` / `sicarx_list_branches` / `sicarx_select_branch` —
  descubrir y elegir la sucursal activa.
- **Catálogo de productos**: buscar, listar, ver detalle, dar de alta,
  editar, subir/seleccionar imágenes (flujo S3 confirmado en producción),
  verificar SKU, consultar/restaurar productos borrados.
- **Stock e inventario**: consultar existencias, historial/kardex, y el
  flujo de ajustes manuales (crear movimiento → detalle → aplicar), más
  `sicarx_adjust_inventory` como atajo de alto nivel para dejar el stock en
  un número exacto de un jalón.
- **Ventas y compras**: la vía confirmada que funciona es `sicarx_report`
  con `report:"sales"|"purchases"`, `variant:"data"` — ver "Herramientas
  deshabilitadas" abajo.
- **Clientes/proveedores (agentes)**: listar con búsqueda real vía GraphQL,
  ver detalle, crédito, alta/edición.
- **Caja registradora**: listar cajas, cortes/balances, formas de pago,
  transacciones (entrada/salida de efectivo), desbloqueo y cierre.
- `sicarx_list_reports` / `sicarx_report` — ~20 reportes de negocio (ventas,
  compras, caja, productos, devoluciones, CFDI, créditos y pagos de
  clientes/proveedores), con variantes `data` / `summary` / `export`
  (descarga el Excel/CSV a `~/Downloads/sicarx-reports`).
- `sicarx_get_currencies`, `sicarx_get_payment_options`,
  `sicarx_cash_register_balance_list` — atajos de configuración/caja.
- `sicarx_raw_request` — llamar cualquier endpoint (método, path, query,
  body, nivel de autenticación) para lo que no tiene herramienta dedicada
  todavía. Es la vía recomendada para confirmar en vivo un endpoint nuevo
  (con pruebas empíricas) antes de convertirlo en una `server.tool` dedicada.

### Herramientas deshabilitadas

`sicarx_list_sales`, `sicarx_get_sale`, `sicarx_list_purchases`,
`sicarx_get_purchase` están **deshabilitadas** (`.disable()` en el código,
justo antes de `main()`) — confirmado que el gateway de SICAR-X devuelve 503
consistente en esos 4 endpoints para esta cuenta. Siguen en el código por si
algún día se arregla, pero no aparecen en la lista de herramientas ni se
pueden invocar. Usa `sicarx_report(report:"sales"|"purchases",
variant:"data")` en su lugar. Detalle completo en `API.md`.

Varias otras herramientas de **escritura** (crear/editar agentes, formas de
pago, transacciones y cierre de caja) están marcadas en su descripción como
⚠️ no confirmadas a fondo contra datos reales — revisa `API.md` antes de
usarlas con datos que importen.

## Instalación

```bash
cd sicarx-mcp
npm install
cp .env.example .env
```

Edita `.env` con tu correo y contraseña de SICAR-X (las mismas que usas para
entrar a la app). Puedes dejar `SICARX_BRANCH_ID` vacío: en ese caso, antes
de usar reportes u otras herramientas, pide a Claude que llame
`sicarx_list_companies` → `sicarx_list_branches` → `sicarx_select_branch`
para elegir la sucursal.

## Conectarlo a Claude Desktop

Agrega esto a tu `claude_desktop_config.json` (Configuración → Developer →
Edit Config), ajustando la ruta absoluta a donde quede esta carpeta:

```json
{
  "mcpServers": {
    "sicarx": {
      "command": "node",
      "args": ["/ruta/absoluta/a/sicarx-mcp/src/index.js"]
    }
  }
}
```

Reinicia Claude Desktop. Deberías ver las herramientas `sicarx_*`
disponibles en el selector de herramientas MCP.

## Seguridad

- Las credenciales quedan solo en tu `.env` local; el servidor corre en tu
  máquina y nunca las envía a Claude ni a Anthropic, solo al backend de
  SICAR-X (igual que la app oficial).
- Los tokens JWT se guardan en memoria del proceso del servidor, no en
  disco.
- No compartas tu `.env` ni lo subas a un repositorio.

## Cómo se descubrieron los endpoints

A partir de `app.asar` desempaquetado (Electron), específicamente
`node_modules/@sicarx/sxw-api/dist/`, que contiene el cliente HTTP
(`utils/request.js`, `utils/paths.js`), el flujo de login
(`services/login/*`) y los 20+ módulos de reportes
(`services/reports/*`). El interceptor de autenticación real está en
`guard/withAxios.js`.
