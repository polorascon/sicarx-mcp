#!/usr/bin/env node
/**
 * sicarx-mcp — Servidor MCP no oficial para la API privada de SICAR-X.
 *
 * Reconstruido por ingeniería inversa del cliente Electron/React de SICAR-X
 * (app.asar -> node_modules/@sicarx/sxw-api). No es un producto oficial de
 * SICAR Solutions; la API puede cambiar sin aviso. Úsalo con tu propia
 * cuenta y respeta los términos de servicio del proveedor.
 */

import path from "node:path";
import os from "node:os";
import fs from "node:fs/promises";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";
import dotenv from "dotenv";
import axios from "axios";
import { z } from "zod";
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { StreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/streamableHttp.js";
import http from "node:http";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
dotenv.config({ path: path.join(__dirname, "..", ".env") });

// ---------------------------------------------------------------------------
// Configuración
// ---------------------------------------------------------------------------

const BASE_URL = process.env.SICARX_BASE_URL || "https://api.sicarx.com/";
const EMAIL = process.env.SICARX_EMAIL || "";
const PASSWORD = process.env.SICARX_PASSWORD || "";
const DEVICE_ID = process.env.SICARX_DEVICE_ID || "claude-mcp";
const DEVICE_ALIAS = process.env.SICARX_DEVICE_ALIAS || "Claude MCP";
const DEVICE_TYPE = process.env.SICARX_DEVICE_TYPE || "web";
const DEFAULT_BRANCH_ID = process.env.SICARX_BRANCH_ID || "";

const COMPANY_URL = "/company/v1";
const ACCOUNT_URL = "/account/v1";
const SETTINGS_URL = "/settings/v1";
const CASH_REGISTER_QUERIES_URL = "/cashregister/v1/queries";
const CASH_REGISTER_BALANCING_QUERIES_URL = "/cashregister/v1/balancing-queries";
const SALES_REPORTS = "/sales-reports/v1";
const PRODUCT_URL = "/product/v1";
const DEPARTMENT_URL = "/department/v1";
const UNIT_URL = "/unit/v1";
const STOCK_URL = "/stock/v1";
const MOVEMENT_URL = "/movement/v1";
const PRICES_URL = "/prices/v1";
const IMAGE_URL = "/product/v1/image";
const SEARCH_URL = "/search/v1/search";
const DELETED_PRODUCT_URL = "/product/v1/deleted";
const STOCK_REPORTS_URL = "/stock-reports/v1";
const AGENT_URL = "/agent/v1";
const DOCUMENT_GRAPH_URL = "/document-graph/v1";
const SALES_QUERIES_URL = "/sales-queries/v1";
const PURCHASES_QUERIES_URL = "/purchases-queries/v1";
const CASH_REGISTER_URL = "/cashregister/v1";

// Imágenes de producto (reverse-engineered de sxw-api/dist/services/product/images.js
// y sxw-product/dist/features/product/clases/Product.js):
//   1. POST product/v1/image/signUrl { productUuid, imageUuid, contentType, contentLength, selected }
//      -> response.data es un string: la URL firmada de S3 para subir el archivo.
//   2. PUT directo a esa URL firmada (SIN el Authorization de SICAR-X — es S3, no la API),
//      body = bytes crudos del archivo, headers EXACTOS (van incluidos en la firma):
//        Content-Type: <contentType>
//        x-amz-meta-content-id: <contentId de la empresa, viene del JWT de companyToken, claim "x">
//        x-amz-meta-product-id: <productUuid>
//        x-amz-meta-selected: "true"|"false"
//      No hace falta ningún paso de confirmación posterior: el backend de SICAR-X procesa
//      el objeto subido a S3 (probablemente vía evento S3) usando esos metadatos para
//      asociarlo al producto. Esto es válido para subir una imagen NUEVA.
//   3. POST product/v1/image/select/{productUuid}/{imageUuid} (body vacío) sólo se usa para
//      cambiar cuál imagen YA EXISTENTE es la seleccionada/principal — no es parte de la
//      subida de una imagen nueva.
// El "contentId" sale del claim "x" del companyToken (ver sicarx_whoami) — no confirmado al
// 100% por falta de un endpoint que lo etiquete explícitamente, pero es el único campo numérico
// del token no usado en otro lado y encaja con el patrón de "contentId" como identificador de
// empresa/tenant usado para particionar el storage local de la app.

// ---------------------------------------------------------------------------
// Movimientos de inventario (movement/v1/movement) — notas de ingeniería
// inversa + pruebas empíricas contra una cuenta real (2026-09-02).
//
// El enum MovementType real está en
// node_modules/@sicarx/sxw-api/dist/models/enums/productTypes.js:
//   INGRESS = 0, EGRESS = 1, FREE = 2
// (Ojo: hay una tabla de traducción de UI en InventoryView.js, h={2:INGRESS,
// 3:EGRESS,4:FREE}, que NO son los valores reales del enum — es solo un mapeo
// de un selector local de la interfaz a estos 3 valores. type=4 de hecho es
// inválido ("Invalid type value"); type=3 SÍ es válido pero no es EGRESS del
// enum, es otro tipo de movimiento no identificado con semántica de resta
// (ver abajo) — probablemente el que la UI de "conteo/ajuste" arma con más
// metadata. No usar type=3 a ciegas asumiendo que es EGRESS.)
//
// Semántica de 'quantity' en movement/v1/movement/detail/{uuid} (PUT),
// confirmada probando contra datos reales:
//   - type=2 (FREE): al aplicar, el stock del producto queda EXACTAMENTE
//     igual a 'quantity' (set absoluto, sube o baja sin restricción).
//     'currentStock' NO se usa en el cálculo, solo quedó como referencia en
//     el detalle. Éste es el mecanismo que usa sicarx_adjust_inventory.
//   - type=1 (EGRESS, o el "type=3" observado con el mismo comportamiento):
//     newStock = currentStock_enviado - quantity_enviado. El backend valida
//     que el resultado sea una baja real respecto al stock REAL del sistema
//     (no solo respecto al currentStock que uno mande) — si no baja, rechaza
//     con "contains negative quantity" en el paso de agregar detalle.
//   - type=0 (INGRESS): no se probó a fondo: se creó un movimiento pero no
//     se le agregaron detalles ni se aplicó.
//
// applyMovement (POST movement/v1/movement/apply) espera el uuid del
// movimiento como body — pero como STRING JSON crudo, no como objeto
// {uuid:...}. Axios manda application/x-www-form-urlencoded por default
// cuando el body es un string; SICAR-X lo rechaza con 415. Hay que forzar
// headers: {"Content-Type": "application/json"} y mandar
// JSON.stringify(movementUuid) como body.
//
// movement/v1/movement requiere priceListUuid (400 "PriceListUuid can't be
// null" si falta) — se resuelve automático con getDefaultPriceListUuid().
// ---------------------------------------------------------------------------

// Cache en memoria del uuid de la lista de precios "predeterminada" de la
// sucursal, para no tener que pedirlo cada vez en sicarx_adjust_inventory.
let cachedPriceListUuid = null;
async function getDefaultPriceListUuid() {
  if (cachedPriceListUuid) return cachedPriceListUuid;
  const res = await apiClient.get(`${PRICES_URL}/priceList/list`);
  const list = Array.isArray(res.data) ? res.data : [];
  const preferred = list.find((p) => p.predetermined) || list[0];
  if (!preferred?.uuid) {
    throw new Error(
      "No se encontró ninguna lista de precios (prices/v1/priceList/list). Pasa priceListUuid manualmente."
    );
  }
  cachedPriceListUuid = preferred.uuid;
  return cachedPriceListUuid;
}

// El login (/login/v1/account y /login/v1/login) NO vive en api.sicarx.com
// (ahí esa ruta da 503 "Not Found" de gateway, incluso desde la propia app
// web) — vive en una AWS Lambda Function URL aparte. Confirmado inspeccionando
// el tráfico real de https://app.sicarx.com. El resto de la API sí es
// api.sicarx.com normal.
const LOGIN_BASE_URL =
  process.env.SICARX_LOGIN_BASE_URL ||
  "https://7ew5wkc4jsnbb6ph2bd2r4o5540hqlea.lambda-url.us-east-1.on.aws";

// ---------------------------------------------------------------------------
// Utilidades JWT (sólo para leer exp/claims, no se valida la firma: la
// validación real la hace el backend de SICAR-X en cada request)
// ---------------------------------------------------------------------------

function decodeJwt(token) {
  if (!token || typeof token !== "string" || token.split(".").length !== 3) {
    return null;
  }
  try {
    const payload = token.split(".")[1];
    const json = Buffer.from(payload, "base64url").toString("utf8");
    return JSON.parse(json);
  } catch {
    return null;
  }
}

function isExpired(token, skewSeconds = 30) {
  const claims = decodeJwt(token);
  if (!claims?.exp) return true;
  return Date.now() / 1000 >= claims.exp - skewSeconds;
}

// ---------------------------------------------------------------------------
// Estado de sesión (en memoria, vive mientras corre el proceso del server)
// ---------------------------------------------------------------------------

const session = {
  accountJwt: null,
  companyJwt: null,
  companyId: null,
  branchId: DEFAULT_BRANCH_ID || null,
};

const loginClient = axios.create({ baseURL: LOGIN_BASE_URL, timeout: 30000 });

// El cliente oficial (app.asar) nunca manda la contraseña en texto plano al
// endpoint de login de cuenta: la transforma con SHA-512 y manda el hash en
// hexadecimal (128 caracteres). Confirmado ejecutando de forma aislada la
// función real de hash extraída de dist/assets/@sicarx/sxw-api-*.js (la que
// arma la petición de la pantalla de login inicial) contra vectores de
// prueba conocidos: coincide byte a byte con CryptoJS.SHA512(...).toString(Hex).
// (Nota: services/login/*.js expone una función SHA-256 distinta, usada solo
// para la reautenticación de "settings", no para este login inicial.)
function hashPassword(plain) {
  return crypto.createHash("sha512").update(plain, "utf8").digest("hex");
}

function extractJwt(data) {
  if (typeof data === "string") return data;
  if (data?.jwt) return data.jwt;
  if (data?.data?.jwt) return data.data.jwt;
  if (data?.token) return data.token;
  return null;
}

async function loginAccount() {
  if (!EMAIL || !PASSWORD) {
    throw new Error(
      "Faltan SICARX_EMAIL / SICARX_PASSWORD en el archivo .env del servidor MCP."
    );
  }
  const { data } = await loginClient.post("/login/v1/account", {
    email: EMAIL,
    password: hashPassword(PASSWORD),
    deviceId: DEVICE_ID,
    deviceAlias: DEVICE_ALIAS,
    deviceType: DEVICE_TYPE,
  });
  const jwt = extractJwt(data);
  if (!jwt) {
    throw new Error(
      `Login de cuenta no devolvió un JWT reconocible. Respuesta cruda: ${JSON.stringify(data)}`
    );
  }
  session.accountJwt = jwt;
  return jwt;
}

async function ensureAccountToken() {
  if (session.accountJwt && !isExpired(session.accountJwt)) {
    return session.accountJwt;
  }
  return loginAccount();
}

async function loginCompany(branchId) {
  if (!branchId) {
    throw new Error(
      "No hay branchId configurado. Usa la herramienta sicarx_select_branch o define SICARX_BRANCH_ID en .env."
    );
  }
  const accountJwt = await ensureAccountToken();
  // El backend espera branchId como número (confirmado en dist/assets del
  // cliente oficial: "branchId:Number(...)"), no como string.
  const res = await loginClient.post("/login/v1/login", {
    jwt: accountJwt,
    branchId: Number(branchId),
  });
  const data = res.data;
  // El JWT de sucursal NO viene en el body (eso son los permisos otorgados);
  // viene en el header de respuesta "cauth" ("company auth").
  const jwt = res.headers?.cauth || res.headers?.["cauth"] || extractJwt(data);
  if (!jwt) {
    throw new Error(
      `Login de sucursal no devolvió un JWT reconocible. Headers: ${JSON.stringify(
        res.headers
      )}. Respuesta cruda: ${JSON.stringify(data)}`
    );
  }
  session.companyJwt = jwt;
  session.branchId = branchId;
  return jwt;
}

async function ensureCompanyToken() {
  if (session.companyJwt && !isExpired(session.companyJwt)) {
    return session.companyJwt;
  }
  return loginCompany(session.branchId || DEFAULT_BRANCH_ID);
}

// ---------------------------------------------------------------------------
// Cliente HTTP autenticado (nivel "company", el que usa la mayoría de la app)
// ---------------------------------------------------------------------------

const apiClient = axios.create({ baseURL: BASE_URL, timeout: 30000 });

apiClient.interceptors.request.use(async (config) => {
  const authLevel = config.__authLevel || "company";
  if (authLevel === "company") {
    config.headers.Authorization = await ensureCompanyToken();
  } else if (authLevel === "account") {
    config.headers.Authorization = await ensureAccountToken();
  }
  return config;
});

apiClient.interceptors.response.use(
  (res) => res,
  async (error) => {
    const config = error.config;
    // Si el 401 viene del propio login de cuenta/sucursal (credenciales
    // inválidas), NO hay que reintentar: config aquí sería el de loginClient
    // (sin __authLevel), y reenviarlo por apiClient dispararía por accidente
    // el flujo de nivel "company" -> loginCompany() sin branchId, ocultando
    // el verdadero error de credenciales detrás de un mensaje confuso.
    const isLoginCall =
      typeof config?.url === "string" &&
      (config.url.includes("/login/v1/account") || config.url.includes("/login/v1/login"));
    if (error.response?.status === 401 && config && !config._retry && !isLoginCall) {
      config._retry = true;
      // fuerza relogin y reintenta una vez
      session.companyJwt = null;
      session.accountJwt = null;
      return apiClient(config);
    }
    return Promise.reject(error);
  }
);

function toQueryString(params = {}) {
  const usp = new URLSearchParams();
  for (const [key, value] of Object.entries(params)) {
    if (value === undefined || value === null || value === "") continue;
    if (Array.isArray(value)) {
      usp.append(key, value.join(","));
    } else {
      usp.append(key, String(value));
    }
  }
  return usp.toString();
}

function errorToText(err) {
  if (err.response) {
    return `HTTP ${err.response.status} ${err.response.statusText || ""}\n${JSON.stringify(
      err.response.data,
      null,
      2
    )}`;
  }
  return err.message || String(err);
}

function textResult(value) {
  const text = typeof value === "string" ? value : JSON.stringify(value, null, 2);
  return { content: [{ type: "text", text }] };
}

function errorResult(err) {
  return { content: [{ type: "text", text: `Error: ${errorToText(err)}` }], isError: true };
}

// ---------------------------------------------------------------------------
// Catálogo de reportes (extraído de sxw-api/dist/services/reports/*)
// Todos cuelgan de SALES_REPORTS = "/sales-reports/v1".
// ---------------------------------------------------------------------------

const REPORTS = {
  sales: {
    path: "reports/sales",
    summaryPath: "reports/sales/summary",
    exportPath: "reports/sales/export",
    doc: "Ventas. Params: startDate,endDate,timeZone,taxFilter,dateField,language,agentUuid,sellerUuid,userUuid,serie,status,isoCurrency,discount,salePayment,warehouseId[],branch[],includeSaleRefunds,rps,limit,offset",
  },
  salesProfit: {
    path: "reports/salesProfit",
    doc: "Utilidad de ventas. Params: startDate,endDate,timeZone,taxFilter,dateField,language,agentUuid,sellerUuid,userUuid,serie,status,isoCurrency,discount,documentType,...",
  },
  salesByAgent: {
    path: "reports/salesByAgent",
    summaryPath: "reports/salesByAgent/summary",
    doc: "Ventas por cliente/agente. Params: startDate,endDate,taxFilter,sortBy,sortOrder,timeZone,language,agentUuid,discount,limit,offset",
  },
  salesByDepartmentWithTaxes: {
    path: "salesByDepartment/withTaxes",
    exportPath: "salesByDepartment/withTaxes/export",
    doc: "Ventas por departamento (con impuestos). Params: startDate,endDate,timeZone,pageNumber,language,groupDepartments,department[],category[],includeSaleRefunds,sellerUuid,userUuid",
  },
  salesByDepartmentWithoutTaxes: {
    path: "salesByDepartment/withoutTaxes",
    exportPath: "salesByDepartment/withoutTaxes/export",
    doc: "Ventas por departamento (sin impuestos). Mismos params que salesByDepartmentWithTaxes.",
  },
  salesByUserWithTaxes: {
    path: "salesByUser/withTaxes",
    exportPath: "salesByUser/withTaxes/export",
    doc: "Ventas por usuario. Params: startDate,endDate,sortBy,sortOder,timeZone,dateField,pageNumber,language,seller(true|false),excludeColumns[],includeSaleRefunds",
  },
  salesByUserWithoutTaxes: {
    path: "salesByUser/withoutTaxes",
    exportPath: "salesByUser/withoutTaxes/export",
    doc: "Ventas por usuario, sin impuestos. Mismos params que salesByUserWithTaxes.",
  },
  ordersByUserWithTaxes: {
    path: "ordersByUser/withTaxes",
    exportPath: "ordersByUser/withTaxes/export",
    doc: "Ventas por mesero/waitress. Params: startDate,endDate,sortBy,sortOder,timeZone,dateField,pageNumber,language,excludeColumns[]",
  },
  ordersByUserWithoutTaxes: {
    path: "ordersByUser/withoutTaxes",
    exportPath: "ordersByUser/withoutTaxes/export",
    doc: "Ventas por mesero/waitress, sin impuestos. Mismos params que ordersByUserWithTaxes.",
  },
  products: {
    path: "products/withTaxes",
    doc: "Ventas por producto. Params: startDate,endDate,timeZone,pageNumber,language,agent,seller,user,status,product,includeSaleRefunds,groupProducts,sortBy,sortOrder,department[],category[]",
  },
  refundsWithTaxes: {
    path: "saleRefundsMongo/withTaxes",
    exportPath: "saleRefundsMongo/withTaxes/export",
    doc: "Devoluciones (con impuestos). Params: startDate,endDate,timeZone,dateField,pageNumber,agentUuid,sellerUuid,userUuid,serie,refundPayment,status,isoCurrency,discount,warehouseId[],branch[]",
  },
  refundsWithoutTaxes: {
    path: "saleRefundsMongo/withoutTaxes",
    exportPath: "saleRefundsMongo/withoutTaxes/export",
    doc: "Devoluciones (sin impuestos). Mismos params que refundsWithTaxes.",
  },
  orders: {
    path: "reports/orders",
    summaryPath: "reports/orders/summary",
    exportPath: "reports/orders/export",
    doc: "Comandas/pedidos. Params: startDate,endDate,timeZone,taxFilter,language,userUuid,serie,status,branch[],isoCurrency,discount,limit,offset",
  },
  purchases: {
    path: "reports/purchases",
    summaryPath: "reports/purchases/summary",
    exportPath: "reports/purchases/export",
    doc: "Compras. Params: startDate,endDate,timeZone,taxFilter,dateField,language,agentUuid,sellerUuid,userUuid,serie,warehouseId[],branch[],status,isoCurrency,discount,paymentId,invoiced,limit,offset",
  },
  purchasesBySupplier: {
    path: "reports/purchasesBySupplier",
    summaryPath: "reports/purchasesBySupplier/summary",
    doc: "Compras por proveedor. Params: startDate,endDate,taxFilter,sortBy,sortOrder,timeZone,language,agentUuid,discount,limit,offset",
  },
  purchasesByProducts: {
    path: "purchasesByProduct/withTaxes",
    doc: "Compras por producto. Params: startDate,endDate,timeZone,pageNumber,language,agent,seller,user,status,product,groupProducts,sortBy,sortOrder,department[],category[]",
  },
  cashMovements: {
    path: "transactionsBranches",
    nextPagePath: "transactionsBranches/nextPage",
    doc: "Movimientos de caja (todas las sucursales). Params: startDate,endDate,timeZone,language,datePattern,transactionType,operationType,paymentOption,isoCurrency,cashRegisterUuid,userUuid,branch[]. Paginación: usa cashMovementsNextPage con offset.",
  },
  cfdiExport: {
    path: "cfdiReport/export",
    blob: true,
    doc: "Excel de CFDIs emitidos. Params: startDate,endDate,timeZone,dateField,language,datePattern,status,isoCurrency",
  },
  cfdiCreditNoteExport: {
    path: "cfdiRefundReport/export",
    blob: true,
    doc: "Excel de notas de crédito CFDI. Mismos params que cfdiExport.",
  },
  agentCreditsReport: {
    path: "agentCreditsReport",
    exportPath: "agentCreditsReport/export",
    doc: "Créditos por agente (cliente o proveedor). Params: agentType=CLIENT|SUPPLIER (obligatorio), startDate,endDate ó date_range,overdue,datePattern,timeZone,pageNumber,dateFieldReport,language",
  },
  agentPaymentsReport: {
    path: "agentPaymentsReport",
    doc: "Pagos por agente (cliente o proveedor). Params: agentType=CLIENT|SUPPLIER (obligatorio), start_date,end_date,date_pattern,status,time_zone,pageNumber,dateFieldReport,language,agent",
  },
  kardex: {
    path: "reports/products/kardex/export",
    blob: true,
    doc: "Kardex de movimientos de stock por producto (entradas/salidas/ajustes en el rango de fechas), como Excel. Params: startDate,endDate,timeZone,dateField,productUuid,warehouseId[],categoryId,departmentId,agentUuid,status. Solo existe como export (no hay variante 'data' en JSON confirmada) — siempre descarga un archivo.",
  },
};

async function fetchReport(reportKey, variant, params, extraOpts = {}) {
  const spec = REPORTS[reportKey];
  if (!spec) {
    throw new Error(
      `Reporte desconocido: "${reportKey}". Usa sicarx_list_reports para ver los disponibles.`
    );
  }
  let subPath = spec.path;
  if (variant === "summary") {
    if (!spec.summaryPath) throw new Error(`El reporte "${reportKey}" no tiene variante summary.`);
    subPath = spec.summaryPath;
  } else if (variant === "export") {
    if (!spec.exportPath && !spec.blob) throw new Error(`El reporte "${reportKey}" no tiene variante export.`);
    subPath = spec.exportPath || spec.path;
  } else if (variant === "nextPage") {
    if (!spec.nextPagePath) throw new Error(`El reporte "${reportKey}" no soporta paginación por offset.`);
    subPath = spec.nextPagePath;
  }

  const qs = toQueryString(params);
  const url = `${SALES_REPORTS}/${subPath}${qs ? `?${qs}` : ""}`;
  const isBlob = spec.blob || variant === "export";

  const res = await apiClient.get(url, {
    responseType: isBlob ? "arraybuffer" : "json",
    ...extraOpts,
  });

  if (!isBlob) {
    return { kind: "json", data: res.data };
  }

  const contentType = res.headers["content-type"] || "application/octet-stream";
  const ext = contentType.includes("spreadsheet") || contentType.includes("excel")
    ? "xlsx"
    : contentType.includes("csv")
    ? "csv"
    : contentType.includes("pdf")
    ? "pdf"
    : "bin";
  const dir = path.join(os.homedir(), "Downloads", "sicarx-reports");
  await fs.mkdir(dir, { recursive: true });
  const fileName = `${reportKey}-${Date.now()}.${ext}`;
  const filePath = path.join(dir, fileName);
  await fs.writeFile(filePath, Buffer.from(res.data));
  return { kind: "file", filePath, contentType, bytes: res.data.byteLength };
}

// ---------------------------------------------------------------------------
// Servidor MCP
// ---------------------------------------------------------------------------

const server = new McpServer({ name: "sicarx-mcp", version: "0.1.0" });

server.tool(
  "sicarx_whoami",
  "Muestra el estado de la sesión actual contra SICAR-X: si hay token de cuenta/sucursal, cuándo expiran y qué branchId está activo. Útil para diagnosticar problemas de login.",
  {},
  async () => {
    const accountClaims = decodeJwt(session.accountJwt);
    const companyClaims = decodeJwt(session.companyJwt);
    return textResult({
      email: EMAIL || "(no configurado)",
      branchId: session.branchId,
      accountToken: session.accountJwt
        ? { valid: !isExpired(session.accountJwt), claims: accountClaims }
        : null,
      companyToken: session.companyJwt
        ? { valid: !isExpired(session.companyJwt), claims: companyClaims }
        : null,
    });
  }
);

server.tool(
  "sicarx_list_companies",
  "Lista las empresas (companies) a las que tiene acceso la cuenta autenticada. Usa el token de cuenta (no requiere sucursal seleccionada).",
  {},
  async () => {
    try {
      const res = await apiClient.get(`${COMPANY_URL}/company/list`, {
        __authLevel: "account",
      });
      return textResult(res.data);
    } catch (err) {
      return errorResult(err);
    }
  }
);

server.tool(
  "sicarx_list_branches",
  "Lista las sucursales (branch offices) de una empresa. Usa el token de cuenta. Pasa companyUuid si lo conoces (de sicarx_list_companies); si no, intenta listar sin filtro.",
  { companyUuid: z.string().optional() },
  async ({ companyUuid }) => {
    try {
      const qs = companyUuid ? `?companyUuid=${encodeURIComponent(companyUuid)}` : "";
      const res = await apiClient.get(`${COMPANY_URL}/branchOffice/list${qs}`, {
        __authLevel: "account",
      });
      return textResult(res.data);
    } catch (err) {
      return errorResult(err);
    }
  }
);

server.tool(
  "sicarx_select_branch",
  "Inicia sesión de sucursal (branch) con el branchId indicado y deja ese token activo para el resto de herramientas (reportes, etc.). Equivale a 'entrar' a esa sucursal en la app.",
  { branchId: z.string().min(1) },
  async ({ branchId }) => {
    try {
      await loginCompany(branchId);
      return textResult({ ok: true, branchId, expires: decodeJwt(session.companyJwt)?.exp });
    } catch (err) {
      return errorResult(err);
    }
  }
);

server.tool(
  "sicarx_list_reports",
  "Lista los reportes disponibles a través de sicarx_report, con la descripción de sus parámetros.",
  {},
  async () => {
    const list = Object.entries(REPORTS).map(([key, spec]) => ({
      report: key,
      variants: ["data", spec.summaryPath ? "summary" : null, (spec.exportPath || spec.blob) ? "export" : null, spec.nextPagePath ? "nextPage" : null].filter(Boolean),
      doc: spec.doc,
    }));
    return textResult(list);
  }
);

server.tool(
  "sicarx_report",
  "Consulta un reporte de SICAR-X (ventas, compras, caja, productos, CFDI, créditos de agentes, etc.). Usa sicarx_list_reports para ver los reportes y parámetros disponibles. variant='export' descarga el Excel/CSV/PDF a ~/Downloads/sicarx-reports y devuelve la ruta del archivo en vez del JSON. ✅ Confirmado en vivo el 2026-09-02: report='sales'/'purchases' con variant='data' es la forma CONFIABLE de listar ventas/compras (con folio, uuid, totales, agente, tipo SALE/SALE_REFUND) — úsalo en vez de sicarx_list_sales/sicarx_list_purchases, que dan 503 de gateway consistentemente. 'taxFilter' es obligatorio para los reportes de ventas/compras (usa 'WITH_TAXES'). ⚠️ Gotcha: en variant='data', NO mandes params.offset=0 explícito en la primera página (el backend intenta decodificarlo como cursor base64 y truco de paginación de BigQuery y tira 500 Internal Server Error) — omite 'offset' por completo para la primera página; en variant='data', 'limit' tiene un mínimo de 10.",
  {
    report: z.string().describe("Clave del reporte, ver sicarx_list_reports"),
    variant: z.enum(["data", "summary", "export", "nextPage"]).default("data"),
    params: z
      .record(z.any())
      .default({})
      .describe(
        "Parámetros de query tal como los espera el endpoint (ver doc del reporte). Ej: {startDate:'2026-08-01', endDate:'2026-08-31', timeZone:'America/Chihuahua'}"
      ),
  },
  async ({ report, variant, params }) => {
    try {
      const result = await fetchReport(report, variant, params);
      if (result.kind === "file") {
        return textResult({
          ok: true,
          message: "Archivo descargado",
          filePath: result.filePath,
          contentType: result.contentType,
          bytes: result.bytes,
        });
      }
      return textResult(result.data);
    } catch (err) {
      return errorResult(err);
    }
  }
);

server.tool(
  "sicarx_get_currencies",
  "Lista las monedas configuradas en la sucursal actual (settings/currencies).",
  {},
  async () => {
    try {
      const res = await apiClient.get(`${SETTINGS_URL}/currency/list`);
      return textResult(res.data);
    } catch (err) {
      return errorResult(err);
    }
  }
);

server.tool(
  "sicarx_list_products",
  "Lista/busca productos del catálogo de la sucursal actual (product/v1/product/list). Sin parámetros trae la primera página tal como la ve la app. Los nombres exactos de filtros/paginación no están 100% confirmados por ingeniería inversa (la app los arma con GraphQL/query builders internos); si algún filtro no aplica, usa 'extraBody' para mandar el body crudo que necesites, o sicarx_raw_request directamente.",
  {
    search: z.string().optional().describe("Texto de búsqueda (nombre, SKU, etc.), si el endpoint lo soporta"),
    limit: z.number().optional().describe("Máximo de productos a devolver, si el endpoint lo soporta"),
    offset: z.number().optional().describe("Desde qué posición empezar (paginación), si el endpoint lo soporta"),
    departmentUuid: z.string().optional(),
    categoryUuid: z.string().optional(),
    extraBody: z
      .record(z.any())
      .optional()
      .describe("Objeto adicional para fusionar/sobreescribir en el body de la petición, por si se necesita un campo no listado arriba"),
  },
  async ({ search, limit, offset, departmentUuid, categoryUuid, extraBody }) => {
    try {
      const body = {
        ...(search !== undefined ? { search } : {}),
        ...(limit !== undefined ? { limit } : {}),
        ...(offset !== undefined ? { offset } : {}),
        ...(departmentUuid !== undefined ? { departmentUuid } : {}),
        ...(categoryUuid !== undefined ? { categoryUuid } : {}),
        ...(extraBody || {}),
      };
      const res = await apiClient.post(`${PRODUCT_URL}/product/list`, body);
      return textResult(res.data);
    } catch (err) {
      return errorResult(err);
    }
  }
);

server.tool(
  "sicarx_get_product",
  "Trae el detalle completo de un producto por su uuid (product/v1/product/{uuid}). Devuelve más campos que sicarx_list_products (sku, description, claveSat, salesUnitUuid, departmentUuid, categoryUuid, saleable, bulk, autoWeigh, favorite, avgPurchasePrice, minProfitPercentage, prices, etc.). Útil como referencia para armar el body de sicarx_create_product o sicarx_edit_product.",
  { uuid: z.string().min(1) },
  async ({ uuid }) => {
    try {
      const res = await apiClient.get(`${PRODUCT_URL}/product/${encodeURIComponent(uuid)}`);
      return textResult(res.data);
    } catch (err) {
      return errorResult(err);
    }
  }
);

server.tool(
  "sicarx_list_departments",
  "Lista los departamentos del catálogo de productos (department/v1/department/list). Cada producto necesita un departmentUuid válido de esta lista para sicarx_create_product.",
  {},
  async () => {
    try {
      const res = await apiClient.get(`${DEPARTMENT_URL}/department/list`);
      return textResult(res.data);
    } catch (err) {
      return errorResult(err);
    }
  }
);

server.tool(
  "sicarx_list_categories",
  "Lista las categorías del catálogo de productos (department/v1/category/list). Cada producto necesita un categoryUuid válido de esta lista para sicarx_create_product.",
  {},
  async () => {
    try {
      const res = await apiClient.get(`${DEPARTMENT_URL}/category/list`);
      return textResult(res.data);
    } catch (err) {
      return errorResult(err);
    }
  }
);

server.tool(
  "sicarx_list_units",
  "Lista las unidades de venta/medida (unit/v1/unit/list) — kilo, pieza, litro, caja, etc. Cada producto necesita un salesUnitUuid válido de esta lista para sicarx_create_product.",
  {},
  async () => {
    try {
      const res = await apiClient.get(`${UNIT_URL}/unit/list`);
      return textResult(res.data);
    } catch (err) {
      return errorResult(err);
    }
  }
);

server.tool(
  "sicarx_create_product",
  "Da de alta un producto nuevo en el catálogo (PUT product/v1/product). ⚠️ Esto escribe directamente en la cuenta real de SICAR-X del usuario — no hay entorno de pruebas. Antes de usarla, obtén departmentUuid/categoryUuid/salesUnitUuid válidos con sicarx_list_departments / sicarx_list_categories / sicarx_list_units, y revisa un producto existente similar con sicarx_get_product como referencia de forma. Debes pasar confirm=true explícitamente (después de que el usuario haya confirmado los datos) o la herramienta se niega a ejecutar.",
  {
    confirm: z.boolean().describe("Debe ser true; es una confirmación explícita de que el usuario ya revisó los datos y quiere crear el producto de verdad."),
    description: z.string().describe("Nombre/descripción del producto tal como aparecerá en el catálogo"),
    sku: z.string().describe("SKU / código de barras del producto"),
    departmentUuid: z.string().describe("uuid de departamento, ver sicarx_list_departments"),
    categoryUuid: z.string().describe("uuid de categoría, ver sicarx_list_categories"),
    salesUnitUuid: z.string().describe("uuid de unidad de venta, ver sicarx_list_units"),
    price: z.number().optional().describe("Precio de venta (se usa para armar el objeto 'prices' si no se manda 'prices' directamente)"),
    priceListUuid: z.string().optional().describe("uuid de la lista de precios a la que aplica 'price', si se conoce"),
    prices: z.record(z.number()).optional().describe("Objeto prices completo tal como lo espera la API ({priceListUuid: monto, ...}); si se manda, tiene prioridad sobre 'price'"),
    bulk: z.boolean().optional().describe("true si se vende a granel (por peso/volumen)"),
    autoWeigh: z.boolean().optional().describe("true si se pesa automáticamente en báscula"),
    saleable: z.boolean().optional().default(true).describe("true si el producto es vendible"),
    type: z.number().optional().describe("Tipo de producto tal como lo usa la API internamente (0 visto en productos normales)"),
    claveSat: z.string().optional().describe("Clave SAT del producto, si aplica facturación"),
    extraBody: z.record(z.any()).optional().describe("Campos adicionales/crudos para fusionar en el body, por si falta algún campo no listado arriba"),
  },
  async ({ confirm, description, sku, departmentUuid, categoryUuid, salesUnitUuid, price, priceListUuid, prices, bulk, autoWeigh, saleable, type, claveSat, extraBody }) => {
    if (!confirm) {
      return errorResult(
        new Error(
          "confirm debe ser true. Antes de crear, confirma con el usuario los datos exactos (nombre, sku, precio, departamento, categoría, unidad) — esto crea un producto real en su cuenta de SICAR-X."
        )
      );
    }
    try {
      const body = {
        description,
        sku,
        departmentUuid,
        categoryUuid,
        salesUnitUuid,
        ...(saleable !== undefined ? { saleable } : {}),
        ...(bulk !== undefined ? { bulk } : {}),
        ...(autoWeigh !== undefined ? { autoWeigh } : {}),
        ...(type !== undefined ? { type } : {}),
        ...(claveSat !== undefined ? { claveSat } : {}),
        ...(prices
          ? { prices }
          : price !== undefined
          ? { prices: priceListUuid ? { [priceListUuid]: price } : { price } }
          : {}),
        ...(extraBody || {}),
      };
      const res = await apiClient.put(`${PRODUCT_URL}/product`, body);
      return textResult(res.data);
    } catch (err) {
      return errorResult(err);
    }
  }
);

server.tool(
  "sicarx_edit_product",
  "Edita un producto existente (PATCH product/v1/product/{uuid}). ⚠️ Escribe en la cuenta real del usuario. Manda solo los campos que quieras cambiar en 'fields'; usa sicarx_get_product primero para ver el estado actual. Requiere confirm=true.",
  {
    confirm: z.boolean().describe("Debe ser true; confirmación explícita de que el usuario ya revisó los cambios."),
    uuid: z.string().min(1).describe("uuid del producto a editar"),
    fields: z.record(z.any()).describe("Campos a actualizar, ej: {description:'Nuevo nombre', prices:{...}, saleable:false}"),
  },
  async ({ confirm, uuid, fields }) => {
    if (!confirm) {
      return errorResult(
        new Error("confirm debe ser true. Confirma con el usuario los cambios antes de aplicarlos.")
      );
    }
    try {
      const res = await apiClient.patch(`${PRODUCT_URL}/product/${encodeURIComponent(uuid)}`, fields);
      return textResult(res.data);
    } catch (err) {
      return errorResult(err);
    }
  }
);

function guessImageContentType(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  if (ext === ".png") return "image/png";
  if (ext === ".jpg" || ext === ".jpeg") return "image/jpeg";
  if (ext === ".webp") return "image/webp";
  if (ext === ".gif") return "image/gif";
  return "image/png";
}

server.tool(
  "sicarx_upload_product_image",
  "Sube una imagen nueva a un producto (flujo de 2 pasos vía URL firmada de S3, reverse-engineered de sxw-product/Product.js). ⚠️ Escribe en la cuenta real del usuario. 'imagePath' debe ser una ruta local accesible desde donde corre este servidor MCP (normalmente en la Mac del usuario, no en la nube). No hace falta ningún paso de confirmación posterior a la subida — el backend de SICAR-X asocia la imagen al producto usando los metadatos S3 (product-id, selected, content-id). Requiere confirm=true.",
  {
    confirm: z.boolean().describe("Debe ser true; confirmación explícita de que el usuario ya revisó la imagen y el producto destino."),
    productUuid: z.string().min(1).describe("uuid del producto al que se le va a asociar la imagen"),
    imagePath: z.string().min(1).describe("Ruta local del archivo de imagen (png/jpg/webp) a subir"),
    selected: z.boolean().optional().default(true).describe("Si true, esta imagen queda como la imagen principal/seleccionada del producto"),
    contentType: z.string().optional().describe("MIME type explícito; si no se manda se infiere de la extensión del archivo"),
  },
  async ({ confirm, productUuid, imagePath, selected, contentType }) => {
    if (!confirm) {
      return errorResult(
        new Error("confirm debe ser true. Confirma con el usuario la imagen y el producto destino antes de subirla.")
      );
    }
    try {
      const bytes = await fs.readFile(imagePath);
      const resolvedContentType = contentType || guessImageContentType(imagePath);
      const imageUuid = crypto.randomUUID();

      const companyJwt = await ensureCompanyToken();
      const claims = decodeJwt(companyJwt);
      const contentId = claims?.x;
      if (contentId === undefined || contentId === null) {
        return errorResult(
          new Error(
            "No se pudo determinar el contentId (claim 'x' del companyToken) para el header x-amz-meta-content-id. Corre sicarx_whoami para inspeccionar el token."
          )
        );
      }

      const signRes = await apiClient.post(`${IMAGE_URL}/signUrl`, {
        productUuid,
        imageUuid,
        contentType: resolvedContentType,
        contentLength: bytes.length,
        selected: !!selected,
      });

      const signedUrl = typeof signRes.data === "string" ? signRes.data : signRes.data?.url || signRes.data?.data;
      if (!signedUrl || typeof signedUrl !== "string") {
        return errorResult(
          new Error(
            `signUrl no devolvió una URL firmada reconocible. Respuesta cruda: ${JSON.stringify(signRes.data)}`
          )
        );
      }

      // PUT directo a S3 — NO usar apiClient aquí (llevaría el Authorization de
      // SICAR-X, que no aplica y probablemente invalidaría la firma de S3).
      const uploadRes = await axios.put(signedUrl, bytes, {
        headers: {
          "Content-Type": resolvedContentType,
          "x-amz-meta-content-id": String(contentId),
          "x-amz-meta-product-id": productUuid,
          "x-amz-meta-selected": selected ? "true" : "false",
        },
        maxBodyLength: Infinity,
        maxContentLength: Infinity,
      });

      return textResult({
        ok: true,
        productUuid,
        imageUuid,
        contentType: resolvedContentType,
        bytes: bytes.length,
        selected: !!selected,
        s3Status: uploadRes.status,
      });
    } catch (err) {
      return errorResult(err);
    }
  }
);

server.tool(
  "sicarx_select_product_image",
  "Marca una imagen YA SUBIDA de un producto como la imagen principal/seleccionada (product/v1/image/select/{productUuid}/{imageUuid}). No es para subir una imagen nueva — para eso usa sicarx_upload_product_image (que ya incluye selected).",
  {
    productUuid: z.string().min(1),
    imageUuid: z.string().min(1),
  },
  async ({ productUuid, imageUuid }) => {
    try {
      const res = await apiClient.post(
        `${IMAGE_URL}/select/${encodeURIComponent(productUuid)}/${encodeURIComponent(imageUuid)}`,
        ""
      );
      return textResult(res.data ?? { ok: true });
    } catch (err) {
      return errorResult(err);
    }
  }
);

server.tool(
  "sicarx_list_price_lists",
  "Lista las listas de precios de la sucursal (prices/v1/priceList/list) — casi todas las cuentas solo tienen una, marcada como 'predetermined'. Su uuid es el que piden movement.priceListUuid al crear un ajuste de inventario (sicarx_adjust_inventory lo detecta solo si no se lo pasas).",
  {},
  async () => {
    try {
      const res = await apiClient.get(`${PRICES_URL}/priceList/list`);
      return textResult(res.data);
    } catch (err) {
      return errorResult(err);
    }
  }
);

server.tool(
  "sicarx_list_warehouses",
  "Lista los almacenes/bodegas (warehouses) de la sucursal actual (stock/v1/warehouse/list). Si la cuenta solo tiene un almacén implícito, puede devolver una lista vacía (204) — en ese caso las herramientas de stock no necesitan warehouseId.",
  {},
  async () => {
    try {
      const res = await apiClient.get(`${STOCK_URL}/warehouse/list`);
      return textResult(res.data);
    } catch (err) {
      return errorResult(err);
    }
  }
);

server.tool(
  "sicarx_get_stock",
  "Consulta las existencias (stock) de un producto por su uuid. Devuelve info resumida (disponible, si maneja lotes/series) y, con detail=true, el detalle por almacén (stock/v1/stock/{uuid}/all).",
  {
    productUuid: z.string().min(1),
    detail: z.boolean().optional().default(false).describe("Si true, trae el detalle por almacén en vez del resumen"),
    branch: z.string().optional().describe("Filtra por branch, si aplica (solo con detail=true)"),
  },
  async ({ productUuid, detail, branch }) => {
    try {
      if (detail) {
        const qs = branch ? `?branch=${encodeURIComponent(branch)}` : "";
        const res = await apiClient.get(`${STOCK_URL}/stock/${encodeURIComponent(productUuid)}/all${qs}`);
        return textResult(res.data);
      }
      const res = await apiClient.get(`${STOCK_URL}/stock/info/${encodeURIComponent(productUuid)}`);
      return textResult(res.data);
    } catch (err) {
      return errorResult(err);
    }
  }
);

server.tool(
  "sicarx_list_movements",
  "Lista los movimientos de inventario (ajustes, entradas, salidas — movement/v1/movement/list) en un rango de fechas. initialDate/endDate son obligatorios (formato ISO, ej '2026-08-01T00:00:00').",
  {
    initialDate: z.string().min(1),
    endDate: z.string().min(1),
    offset: z.number().optional().default(0),
    size: z.number().optional().default(25),
    extraBody: z.record(z.any()).optional().describe("Filtros adicionales crudos para el body, por si hace falta algún campo no listado (ej. warehouseId, type, status)"),
  },
  async ({ initialDate, endDate, offset, size, extraBody }) => {
    try {
      const body = { initialDate, endDate, ...(extraBody || {}) };
      const res = await apiClient.post(
        `${MOVEMENT_URL}/movement/list?offset=${offset}&size=${size}`,
        body
      );
      return textResult(res.data);
    } catch (err) {
      return errorResult(err);
    }
  }
);

server.tool(
  "sicarx_get_movement",
  "Trae el detalle de un movimiento de inventario por su uuid (movement/v1/movement/{uuid}).",
  { uuid: z.string().min(1) },
  async ({ uuid }) => {
    try {
      const res = await apiClient.get(`${MOVEMENT_URL}/movement/${encodeURIComponent(uuid)}`);
      return textResult(res.data);
    } catch (err) {
      return errorResult(err);
    }
  }
);

server.tool(
  "sicarx_create_movement",
  "Crea (pero NO aplica) un movimiento de inventario vacío — es el primer paso de un ajuste de stock. El movimiento queda en estado 'pendiente' hasta que se le agreguen detalles (sicarx_add_movement_detail) y se aplique (sicarx_apply_movement); mientras no se aplique, NO afecta el stock real y se puede borrar con sicarx_delete_movement. MovementType real (confirmado en el enum del código fuente Y probando contra la cuenta real): 0=INGRESS, 1=EGRESS, 2=FREE. type=2 (FREE) es el más simple: al aplicar, deja el stock exactamente en 'quantity' del detalle (set directo, sube o baja, sin condiciones) — es el que usa sicarx_adjust_inventory. type=1 (EGRESS) calcula newStock = currentStock_enviado - quantity_enviado y exige que sea una baja real respecto al stock real del sistema. type=0 (INGRESS) no se probó a fondo. Para el flujo completo de un jalón usa mejor sicarx_adjust_inventory.",
  {
    type: z.number().default(2).describe("Tipo de movimiento (MovementType real: 0=INGRESS, 1=EGRESS, 2=FREE). 2=FREE es el más simple y seguro para dejar el stock en un número exacto."),
    description: z.string().optional().describe("Comentario/motivo del ajuste"),
    title: z.string().optional().describe("Título visible del movimiento; si no se manda, SICAR-X pondría un título por defecto según el tipo (esto no está confirmado para llamadas directas a la API, mejor mandarlo explícito)"),
    warehouse: z.string().optional().describe("uuid del almacén, si la cuenta maneja varios (ver sicarx_list_warehouses)"),
    priceListUuid: z.string().optional().describe("uuid de la lista de precios activa, si se conoce (se ve en sicarx_list_movements de movimientos previos, campo priceListUuid)"),
    extraBody: z.record(z.any()).optional(),
  },
  async ({ type, description, title, warehouse, priceListUuid, extraBody }) => {
    try {
      const resolvedPriceListUuid = priceListUuid || (await getDefaultPriceListUuid());
      const body = {
        uuid: crypto.randomUUID(),
        type,
        ...(description !== undefined ? { description } : {}),
        ...(title !== undefined ? { title } : {}),
        ...(warehouse !== undefined ? { warehouse } : {}),
        priceListUuid: resolvedPriceListUuid,
        ...(extraBody || {}),
      };
      const res = await apiClient.put(`${MOVEMENT_URL}/movement`, body);
      return textResult(res.data);
    } catch (err) {
      return errorResult(err);
    }
  }
);

server.tool(
  "sicarx_add_movement_detail",
  "Agrega (o reemplaza) los productos y cantidades de un movimiento de inventario ya creado (PUT movement/v1/movement/detail/{movementUuid}). El movimiento sigue sin afectar stock real hasta aplicarlo con sicarx_apply_movement. Cada item necesita 'productUuid' y 'quantity'. El significado de 'quantity' depende del type del movimiento (ver sicarx_create_movement): con type=2 (FREE, el común) es el stock final absoluto; con type=1 (EGRESS) es la cantidad a restar de 'currentStock'. 'currentStock' es opcional; con type=2 no afecta el cálculo (solo queda de referencia), con type=1 sí se usa en la resta.",
  {
    movementUuid: z.string().min(1),
    items: z
      .array(
        z.object({
          productUuid: z.string().min(1),
          quantity: z.number().describe("Con type=2 (FREE): cantidad final/contada absoluta. Con type=1 (EGRESS): cantidad a restar de currentStock."),
          currentStock: z.number().optional().describe("Stock del sistema antes del ajuste, si se conoce (solo se usa en el cálculo con type=1/EGRESS)"),
        })
      )
      .min(1),
  },
  async ({ movementUuid, items }) => {
    try {
      const body = items.map((it) => ({
        uuid: it.productUuid,
        quantity: it.quantity,
        ...(it.currentStock !== undefined ? { currentStock: it.currentStock } : {}),
      }));
      const res = await apiClient.put(
        `${MOVEMENT_URL}/movement/detail/${encodeURIComponent(movementUuid)}`,
        body
      );
      return textResult(res.data);
    } catch (err) {
      return errorResult(err);
    }
  }
);

server.tool(
  "sicarx_apply_movement",
  "⚠️ Aplica un movimiento de inventario (POST movement/v1/movement/apply) — este es el paso que REALMENTE modifica las existencias reales del producto en SICAR-X, de forma equivalente a un ajuste hecho desde la app. No es reversible con un simple 'deshacer'; para revertir habría que crear otro movimiento en sentido contrario. Requiere confirm=true.",
  {
    confirm: z.boolean().describe("Debe ser true; confirmación explícita de que el usuario ya revisó los productos/cantidades del movimiento antes de aplicarlo."),
    movementUuid: z.string().min(1),
  },
  async ({ confirm, movementUuid }) => {
    if (!confirm) {
      return errorResult(
        new Error(
          "confirm debe ser true. Este paso cambia el stock real — confirma con el usuario los productos y cantidades (sicarx_get_movement) antes de aplicar."
        )
      );
    }
    try {
      // El body es un string JSON crudo (el uuid entre comillas), no un objeto:
      // axios por default manda application/x-www-form-urlencoded para bodies
      // tipo string, y el backend de SICAR-X lo rechaza (415) — hay que forzar
      // el Content-Type a application/json explícitamente.
      const res = await apiClient.post(
        `${MOVEMENT_URL}/movement/apply`,
        JSON.stringify(movementUuid),
        { headers: { "Content-Type": "application/json" } }
      );
      return textResult(res.data);
    } catch (err) {
      return errorResult(err);
    }
  }
);

server.tool(
  "sicarx_delete_movement",
  "Borra un movimiento de inventario que NO ha sido aplicado todavía (ej. para cancelar un ajuste que se creó por error antes de sicarx_apply_movement). Si el movimiento ya fue aplicado, esto probablemente no revierte el cambio de stock (no confirmado).",
  { movementUuid: z.string().min(1) },
  async ({ movementUuid }) => {
    try {
      const res = await apiClient.delete(`${MOVEMENT_URL}/movement/${encodeURIComponent(movementUuid)}`);
      return textResult(res.data);
    } catch (err) {
      return errorResult(err);
    }
  }
);

server.tool(
  "sicarx_adjust_inventory",
  "⚠️ Herramienta de alto nivel para ACTUALIZAR EL INVENTARIO REAL: hace de un jalón los 3 pasos que hace la app (crear movimiento tipo 'ajuste libre' / MovementType.FREE=2 → agregar productos/cantidades → aplicar) para dejar el stock de uno o más productos en la cantidad EXACTA/ABSOLUTA indicada en 'quantity' (confirmado empíricamente: con type=2 el stock final queda igual a 'quantity', sin importar si sube o baja respecto al stock anterior — NO es una suma ni una resta, es un set directo). Esto escribe directamente en la cuenta real de SICAR-X del usuario — no hay entorno de pruebas, y una vez aplicado no hay 'deshacer' automático (para revertir hay que crear otro ajuste con el valor anterior). Requiere confirm=true, que solo debe mandarse después de que el usuario haya confirmado explícitamente los productos y las cantidades finales — recomienda siempre confirmar el resultado con sicarx_get_stock después de aplicar. Si algo falla después de crear el movimiento pero antes de aplicarlo, el movimiento queda pendiente y sin efecto — se puede reintentar o borrar con sicarx_delete_movement.",
  {
    confirm: z.boolean().describe("Debe ser true; confirmación explícita de que el usuario revisó y aprobó los productos/cantidades exactas antes de escribir en su inventario real."),
    description: z.string().optional().describe("Comentario/motivo del ajuste, ej. 'Conteo físico de fin de mes'"),
    title: z.string().optional().default("Ajuste de inventario (MCP)"),
    warehouse: z.string().optional().describe("uuid del almacén, si aplica (ver sicarx_list_warehouses)"),
    priceListUuid: z.string().optional(),
    items: z
      .array(
        z.object({
          productUuid: z.string().min(1),
          quantity: z.number().describe("Cantidad EXACTA/ABSOLUTA a la que debe quedar el stock de este producto (no es un delta — reemplaza el valor actual)"),
          currentStock: z
            .number()
            .optional()
            .describe("Stock actual del sistema antes del ajuste, si se conoce (solo queda de referencia/auditoría — no afecta el cálculo con type=2/FREE; si no se manda, se consulta automáticamente con sicarx_get_stock antes de crear el movimiento)"),
        })
      )
      .min(1)
      .describe("Lista de productos a ajustar y la cantidad final absoluta a la que debe quedar cada uno"),
    apply: z
      .boolean()
      .optional()
      .default(true)
      .describe("Si false, crea el movimiento y agrega los detalles pero NO lo aplica (queda pendiente, sin efecto en stock real) — útil para revisar antes de confirmar el paso final con sicarx_apply_movement."),
  },
  async ({ confirm, description, title, warehouse, priceListUuid, items, apply }) => {
    if (!confirm) {
      return errorResult(
        new Error(
          "confirm debe ser true. Esto escribe inventario real — confirma con el usuario la lista exacta de productos y cantidades antes de ejecutar."
        )
      );
    }
    const movementUuid = crypto.randomUUID();
    try {
      // 1) Si falta currentStock, lo consultamos para dejar rastro de auditoría.
      const itemsWithStock = [];
      for (const it of items) {
        if (it.currentStock !== undefined) {
          itemsWithStock.push(it);
          continue;
        }
        try {
          const stockRes = await apiClient.get(`${STOCK_URL}/stock/info/${encodeURIComponent(it.productUuid)}`);
          itemsWithStock.push({ ...it, currentStock: stockRes.data?.available ?? stockRes.data?.stock });
        } catch {
          itemsWithStock.push(it);
        }
      }

      // 2) Crear el movimiento (aún no afecta stock).
      // type 2 = ajuste libre ("FREE" en el enum MovementType real del código
      // fuente: INGRESS=0, EGRESS=1, FREE=2). Confirmado empíricamente contra
      // la cuenta real: con type=2, el stock queda exactamente en 'quantity'
      // (set directo, sin importar si sube o baja) — currentStock NO se usa
      // en el cálculo, solo queda de referencia/auditoría en el detalle.
      // (type=1/EGRESS sí usa currentStock: newStock = currentStock - quantity,
      // y exige que el resultado sea menor al stock real; type=0/INGRESS no
      // se probó a fondo. type=2 es el más simple y seguro para "dejar el
      // stock en tal número exacto", que es el caso de uso de esta función.)
      const resolvedPriceListUuid = priceListUuid || (await getDefaultPriceListUuid());
      const movementBody = {
        uuid: movementUuid,
        type: 2,
        description: description ?? null,
        title: title || "Ajuste de inventario (MCP)",
        ...(warehouse !== undefined ? { warehouse } : {}),
        priceListUuid: resolvedPriceListUuid,
      };
      const createRes = await apiClient.put(`${MOVEMENT_URL}/movement`, movementBody);

      // 3) Agregar los detalles (productos + cantidades).
      const detailBody = itemsWithStock.map((it) => ({
        uuid: it.productUuid,
        quantity: it.quantity,
        ...(it.currentStock !== undefined ? { currentStock: it.currentStock } : {}),
      }));
      const detailRes = await apiClient.put(
        `${MOVEMENT_URL}/movement/detail/${encodeURIComponent(movementUuid)}`,
        detailBody
      );

      if (!apply) {
        return textResult({
          ok: true,
          applied: false,
          movementUuid,
          movement: createRes.data,
          detail: detailRes.data,
          note: "Movimiento creado con sus detalles pero NO aplicado. Usa sicarx_apply_movement para aplicarlo, o sicarx_delete_movement para cancelarlo.",
        });
      }

      // 4) Aplicar — este es el paso que sí cambia el stock real.
      const applyRes = await apiClient.post(
        `${MOVEMENT_URL}/movement/apply`,
        JSON.stringify(movementUuid),
        { headers: { "Content-Type": "application/json" } }
      );
      return textResult({
        ok: true,
        applied: true,
        movementUuid,
        movement: createRes.data,
        detail: detailRes.data,
        apply: applyRes.data,
      });
    } catch (err) {
      return {
        content: [
          {
            type: "text",
            text: `Error: ${errorToText(err)}\n\n(movementUuid=${movementUuid} — si el movimiento se alcanzó a crear pero falló un paso posterior, queda pendiente sin aplicar; revisa con sicarx_get_movement o bórralo con sicarx_delete_movement)`,
          },
        ],
        isError: true,
      };
    }
  }
);

server.tool(
  "sicarx_get_payment_options",
  "Lista las formas de pago configuradas para la sucursal actual.",
  { byBranch: z.string().optional().describe("Query string extra tal cual (ej. '?branchId=...'), opcional") },
  async ({ byBranch }) => {
    try {
      const res = await apiClient.get(`${SETTINGS_URL}/paymentOption/list/byBranch${byBranch || ""}`);
      return textResult(res.data);
    } catch (err) {
      return errorResult(err);
    }
  }
);

server.tool(
  "sicarx_cash_register_balance_list",
  "Lista los cortes/balances de caja registrados en un rango de fechas (cashregister/v1/balancing-queries/list). Corregido y confirmado en vivo el 2026-09-02: la ruta correcta es '/balancing-queries/list' (NO '/balancing-queries/balance/list', que da 404) y startDate/endDate/timeZone son obligatorios (400 si falta alguno). Devuelve 204 sin body si no hay cortes en el rango.",
  {
    startDate: z.string().min(1).describe("Fecha inicio, formato YYYY-MM-DD"),
    endDate: z.string().min(1).describe("Fecha fin, formato YYYY-MM-DD"),
    timeZone: z.string().optional().default("America/Chihuahua"),
    extra: z.record(z.any()).optional().describe("Otros query params crudos, si hacen falta"),
  },
  async ({ startDate, endDate, timeZone, extra }) => {
    try {
      const qs = toQueryString({ startDate, endDate, timeZone, ...(extra || {}) });
      const res = await apiClient.get(`${CASH_REGISTER_BALANCING_QUERIES_URL}/list?${qs}`);
      return textResult(res.data);
    } catch (err) {
      return errorResult(err);
    }
  }
);

// ---------------------------------------------------------------------------
// Ronda 2 de herramientas — búsqueda real de productos, productos borrados,
// kardex/historial de stock, ventas y compras (solo lectura), agentes
// (clientes/proveedores) y crédito, caja registradora, formas de pago.
// Reverse-engineered de @sicarx/sxw-api el 2026-09-02. Donde el shape del
// body no se pudo confirmar 100% contra el código fuente (columnas
// "opaco"/"no confirmado" en la investigación), se documenta explícitamente
// en la descripción de la herramienta en vez de inventar campos.
// ---------------------------------------------------------------------------

server.tool(
  "sicarx_search_products",
  "Búsqueda REAL de productos por texto (search/v1/search/product) — a diferencia de sicarx_list_products, este endpoint sí filtra server-side. Úsalo en vez de paginar todo el catálogo a mano.",
  {
    search: z.string().min(1).describe("Texto a buscar (nombre/descripción del producto)"),
    from: z.number().optional().default(0),
    size: z.number().optional().default(10).describe("Mínimo 10 — el servidor rechaza valores menores"),
    priceListId: z.string().optional(),
    type: z.number().optional().describe("Filtro por tipo de producto, si aplica"),
  },
  async ({ search, from, size, priceListId, type }) => {
    try {
      const body = { description: search };
      if (priceListId !== undefined) body.priceListId = priceListId;
      if (type !== undefined) body.type = type;
      const res = await apiClient.post(
        `${SEARCH_URL}/product?from=${encodeURIComponent(from)}&size=${encodeURIComponent(size)}`,
        body
      );
      return textResult(res.data);
    } catch (err) {
      return errorResult(err);
    }
  }
);

server.tool(
  "sicarx_check_sku",
  "Verifica si un SKU ya existe en el catálogo (product/v1/product/checkSku). Útil antes de dar de alta un producto nuevo.",
  { sku: z.string().min(1) },
  async ({ sku }) => {
    try {
      const res = await apiClient.post(`${PRODUCT_URL}/product/checkSku`, sku, {
        headers: { "Content-Type": "text/plain" },
      });
      return textResult(res.data);
    } catch (err) {
      return errorResult(err);
    }
  }
);

server.tool(
  "sicarx_list_deleted_products",
  "Lista productos borrados (product/v1/deleted/list) — para consultarlos o restaurarlos.",
  {
    offset: z.number().optional().default(0),
    items: z.number().optional().default(25),
  },
  async ({ offset, items }) => {
    try {
      const res = await apiClient.get(`${DELETED_PRODUCT_URL}/list?offset=${offset}&items=${items}`);
      return textResult(res.data);
    } catch (err) {
      return errorResult(err);
    }
  }
);

server.tool(
  "sicarx_get_deleted_product",
  "Trae el detalle de un producto borrado por su uuid (product/v1/deleted/{uuid}).",
  { uuid: z.string().min(1) },
  async ({ uuid }) => {
    try {
      const res = await apiClient.get(`${DELETED_PRODUCT_URL}/${encodeURIComponent(uuid)}`);
      return textResult(res.data);
    } catch (err) {
      return errorResult(err);
    }
  }
);

server.tool(
  "sicarx_stock_history",
  "Historial/kardex de movimientos de stock DE TODA LA SUCURSAL (stock-reports/v1/history) en un rango de fechas — confirmado en vivo el 2026-09-02: los campos correctos son 'from'/'until' (no startDate/endDate), y 'productUuid' NO filtra los resultados (siempre trae todos los productos con movimientos en el rango) — hay que filtrar por sku/productUuid del lado del cliente si solo quieres uno. Cada elemento trae oldStock/newStock/oldAvailable/newAvailable, tipo de movimiento (CREATE/SET/EGRESS/INGRESS), folio, usuario, timestamp.",
  {
    from: z.string().min(1).describe("Fecha inicio, formato YYYY-MM-DD"),
    until: z.string().min(1).describe("Fecha fin, formato YYYY-MM-DD"),
    productUuid: z.string().optional().describe("No confirmado que filtre server-side; puede que necesites filtrar tú mismo el resultado"),
    warehouseId: z.string().optional(),
    extra: z.record(z.any()).optional().describe("Campos adicionales crudos para el body, si hacen falta"),
  },
  async ({ from, until, productUuid, warehouseId, extra }) => {
    try {
      const body = { from, until, ...(productUuid ? { productUuid } : {}), ...(warehouseId ? { warehouseId } : {}), ...(extra || {}) };
      const res = await apiClient.post(`${STOCK_REPORTS_URL}/history`, body);
      return textResult(res.data);
    } catch (err) {
      return errorResult(err);
    }
  }
);

server.tool(
  "sicarx_list_lots",
  "Lista los lotes de un producto (stock/v1/lot/list/{productUuid}), si el producto maneja lotes.",
  {
    productUuid: z.string().min(1),
    warehouseUuid: z.string().optional(),
  },
  async ({ productUuid, warehouseUuid }) => {
    try {
      const segment = warehouseUuid
        ? `${encodeURIComponent(warehouseUuid)}/${encodeURIComponent(productUuid)}`
        : encodeURIComponent(productUuid);
      const res = await apiClient.get(`${STOCK_URL}/lot/list/${segment}`);
      return textResult(res.data);
    } catch (err) {
      return errorResult(err);
    }
  }
);

const toolListSales = server.tool(
  "sicarx_list_sales",
  "Lista/busca ventas (sales-queries/v1/list). Solo lectura. ⚠️ CONFIRMADO ROTO el 2026-09-02: este endpoint (y sales-queries/v1/generated/{id} de sicarx_get_sale) devuelve consistentemente HTTP 503 {error:'Not Found', source:'gateway'} sin importar los parámetros — parece un problema de aprovisionamiento del gateway para esta cuenta, no del body/query armado aquí. ALTERNATIVA QUE SÍ FUNCIONA: usa sicarx_report con report='sales', variant='data', params={startDate,endDate,timeZone,taxFilter:'WITH_TAXES'} — trae folio, uuid, totales, agente, tipo (SALE/SALE_REFUND), etc. DESHABILITADA (ver bloque .disable() al final del archivo) — no aparece en la lista de herramientas hasta que se confirme que el gateway ya sirve este endpoint.",
  {
    startDate: z.string().optional(),
    endDate: z.string().optional(),
    timeZone: z.string().optional().default("America/Mexico_City"),
    search: z.string().optional(),
    params: z.record(z.any()).optional().describe("Otros query params: dateField,agentUuid,sellerUuid,userUuid,serie,status,isoCurrency,productUuid,cashRegisterUuid,discount,paymentId,warehouseId"),
  },
  async ({ startDate, endDate, timeZone, search, params }) => {
    try {
      const qs = toQueryString({ startDate, endDate, timeZone, search, ...(params || {}) });
      const res = await apiClient.get(`${SALES_QUERIES_URL}/list${qs ? `?${qs}` : ""}`);
      return textResult(res.data);
    } catch (err) {
      return errorResult(err);
    }
  }
);

const toolGetSale = server.tool(
  "sicarx_get_sale",
  "Trae el detalle generado de una venta por su id (sales-queries/v1/generated/{id}). Solo lectura. ⚠️ CONFIRMADO ROTO el 2026-09-02: mismo problema de gateway 503 que sicarx_list_sales. DESHABILITADA — no aparece en la lista de herramientas.",
  { id: z.string().min(1) },
  async ({ id }) => {
    try {
      const res = await apiClient.get(`${SALES_QUERIES_URL}/generated/${encodeURIComponent(id)}`);
      return textResult(res.data);
    } catch (err) {
      return errorResult(err);
    }
  }
);

const toolListPurchases = server.tool(
  "sicarx_list_purchases",
  "Lista/busca compras (purchases-queries/v1/list). Solo lectura. ⚠️ CONFIRMADO ROTO el 2026-09-02: este endpoint (y purchases-queries/v1/generated/signedUrl/{id} de sicarx_get_purchase) devuelve consistentemente HTTP 503 {error:'Not Found', source:'gateway'} — mismo problema que sicarx_list_sales. ALTERNATIVA QUE SÍ FUNCIONA: usa sicarx_report con report='purchases', variant='data', params={startDate,endDate,timeZone,taxFilter:'WITH_TAXES'}. DESHABILITADA — no aparece en la lista de herramientas.",
  {
    startDate: z.string().optional(),
    endDate: z.string().optional(),
    timeZone: z.string().optional().default("America/Mexico_City"),
    search: z.string().optional(),
    params: z.record(z.any()).optional().describe("Otros query params: dateField,agentUuid,userUuid,serie,status,isoCurrency,productUuid,cashRegisterUuid,discount,paymentId,warehouseId"),
  },
  async ({ startDate, endDate, timeZone, search, params }) => {
    try {
      const qs = toQueryString({ startDate, endDate, timeZone, search, ...(params || {}) });
      const res = await apiClient.get(`${PURCHASES_QUERIES_URL}/list${qs ? `?${qs}` : ""}`);
      return textResult(res.data);
    } catch (err) {
      return errorResult(err);
    }
  }
);

const toolGetPurchase = server.tool(
  "sicarx_get_purchase",
  "Trae la URL firmada del documento generado de una compra por su id (purchases-queries/v1/generated/signedUrl/{id}). Solo lectura. ⚠️ CONFIRMADO ROTO el 2026-09-02: mismo problema de gateway 503 que sicarx_list_purchases. DESHABILITADA — no aparece en la lista de herramientas.",
  { id: z.string().min(1) },
  async ({ id }) => {
    try {
      const res = await apiClient.get(`${PURCHASES_QUERIES_URL}/generated/signedUrl/${encodeURIComponent(id)}`);
      return textResult(res.data);
    } catch (err) {
      return errorResult(err);
    }
  }
);

server.tool(
  "sicarx_list_agents",
  "Lista/busca clientes o proveedores (agentes) vía GraphQL (agent/v1/catalogue/graphToSpecification, query agentsWithCredit). A diferencia del catálogo de productos, este SÍ soporta búsqueda server-side real por nombre. Confirmado contra el schema real de GraphQL (introspección) el 2026-09-02: la respuesta viene envuelta en {hasNext, offset, elements:[AgentWithCredit]}.",
  {
    agentType: z.number().default(2).describe("1=CLIENT, 2=SUPPLIER (numérico, confirmado por introspección del schema GraphQL)"),
    search: z.string().optional().default(""),
    status: z.number().optional().default(1),
    offset: z.number().optional().default(0),
    size: z.number().optional().default(20),
    withCredit: z.boolean().optional().default(false),
  },
  async ({ agentType, search, status, offset, size, withCredit }) => {
    try {
      const query = `query { agentsWithCredit(type: ${agentType}, status: ${status}, search: "${String(search).replace(/"/g, '\\"')}", offset: "${offset}", size: ${size}, withCredit: ${withCredit}) { hasNext offset elements { uuid name alias key emails priceNumber status type imageUrl creditLimit creditDays purchased phoneNumbers { phoneCode phoneNumber phoneType } } } }`;
      const res = await apiClient.post(`${AGENT_URL}/catalogue/graphToSpecification`, { query });
      return textResult(res.data);
    } catch (err) {
      return errorResult(err);
    }
  }
);

server.tool(
  "sicarx_get_agent",
  "Trae el detalle de un cliente/proveedor por uuid (agent/v1/agent/{uuid}/{agentType}).",
  {
    uuid: z.string().min(1),
    agentType: z.number().optional().default(1).describe("1=CLIENT, 2=SUPPLIER (numérico en este endpoint REST, a diferencia de sicarx_list_agents que usa el string)"),
  },
  async ({ uuid, agentType }) => {
    try {
      const res = await apiClient.get(`${AGENT_URL}/agent/${encodeURIComponent(uuid)}/${agentType}`);
      return textResult(res.data);
    } catch (err) {
      return errorResult(err);
    }
  }
);

server.tool(
  "sicarx_create_agent",
  "Da de alta un cliente o proveedor nuevo (POST agent/v1/agent). Campos confirmados por introspección del schema GraphQL (tipo AgentWithCredit) el 2026-09-02: name, alias, priceNumber(Int), type(Int, 1=CLIENT/2=SUPPLIER), key, imageUrl, curp, emails(array de String), phoneNumbers(array de {phoneCode,phoneNumber,phoneType}), comment, birthday, creditLimit, creditDays, status(Int), purchased(Bool), deliveryIntervalDays(Int), externalId. Esto confirma los NOMBRES de campo que existen, pero no garantiza al 100% cuáles son obligatorios para crear — prueba primero con un agente de prueba. Requiere confirm=true.",
  {
    confirm: z.boolean(),
    fields: z.record(z.any()).describe("Campos del agente, ver advertencia de incertidumbre arriba"),
  },
  async ({ confirm, fields }) => {
    if (!confirm) {
      return errorResult(new Error("confirm debe ser true. Este endpoint no está 100% confirmado — revisa la respuesta con cuidado."));
    }
    try {
      const res = await apiClient.post(`${AGENT_URL}/agent`, fields);
      return textResult(res.data);
    } catch (err) {
      return errorResult(err);
    }
  }
);

server.tool(
  "sicarx_edit_agent",
  "Edita un cliente/proveedor existente (PATCH agent/v1/agent/{uuid}/{agentType}). Manda solo los campos que quieras cambiar en 'fields' (igual que sicarx_edit_product). Requiere confirm=true.",
  {
    confirm: z.boolean(),
    uuid: z.string().min(1),
    agentType: z.number().optional().default(1).describe("1=CLIENT, 2=SUPPLIER"),
    fields: z.record(z.any()),
  },
  async ({ confirm, uuid, agentType, fields }) => {
    if (!confirm) {
      return errorResult(new Error("confirm debe ser true."));
    }
    try {
      const res = await apiClient.patch(`${AGENT_URL}/agent/${encodeURIComponent(uuid)}/${agentType}`, fields);
      return textResult(res.data);
    } catch (err) {
      return errorResult(err);
    }
  }
);

server.tool(
  "sicarx_get_agent_credit",
  "Consulta la configuración de crédito de un cliente/proveedor (agent/v1/credit/list/agent/{CLIENT|SUPPLIER}/{agentId}).",
  {
    agentId: z.string().min(1),
    agentType: z.enum(["CLIENT", "SUPPLIER"]).default("SUPPLIER"),
  },
  async ({ agentId, agentType }) => {
    try {
      const res = await apiClient.get(`${AGENT_URL}/credit/list/agent/${agentType}/${encodeURIComponent(agentId)}`);
      return textResult(res.data);
    } catch (err) {
      return errorResult(err);
    }
  }
);

server.tool(
  "sicarx_assign_agent_credit",
  "Asigna/configura una línea de crédito a un cliente o proveedor (POST agent/v1/credit/list/agent). ⚠️ Escribe en la cuenta real. Requiere confirm=true.",
  {
    confirm: z.boolean(),
    agentId: z.string().min(1),
    agentType: z.enum(["CLIENT", "SUPPLIER"]).default("SUPPLIER"),
    creditLimit: z.number(),
    creditDays: z.number(),
    blockCreditIfOverdue: z.boolean().optional().default(false),
  },
  async ({ confirm, agentId, agentType, creditLimit, creditDays, blockCreditIfOverdue }) => {
    if (!confirm) {
      return errorResult(new Error("confirm debe ser true."));
    }
    try {
      const res = await apiClient.post(`${AGENT_URL}/credit/list/agent`, {
        agentType,
        agentId,
        creditLimit,
        creditDays,
        blockCreditIfOverdue,
      });
      return textResult(res.data);
    } catch (err) {
      return errorResult(err);
    }
  }
);

server.tool(
  "sicarx_list_cash_registers",
  "Lista las cajas registradoras configuradas (cashregister/v1/queries/list).",
  {},
  async () => {
    try {
      const res = await apiClient.get(`${CASH_REGISTER_QUERIES_URL}/list`);
      return textResult(res.data);
    } catch (err) {
      return errorResult(err);
    }
  }
);

server.tool(
  "sicarx_get_cash_register",
  "Trae el detalle de una caja registradora por uuid (cashregister/v1/queries/{uuid}).",
  { uuid: z.string().min(1) },
  async ({ uuid }) => {
    try {
      const res = await apiClient.get(`${CASH_REGISTER_QUERIES_URL}/${encodeURIComponent(uuid)}`);
      return textResult(res.data);
    } catch (err) {
      return errorResult(err);
    }
  }
);

server.tool(
  "sicarx_cash_register_transaction",
  "Registra un movimiento de entrada/salida de efectivo en una caja (POST cashregister/v1/cashRegister/transaction). ⚠️⚠️ El valor exacto que espera el campo 'type' para distinguir entrada vs. salida NO se pudo confirmar por ingeniería inversa (es un enum numérico interno, 'Ee.INCOME'/'Ee.EXPENSE', cuyo valor real no se pudo leer del código minificado). NO uses esta herramienta para dinero real sin antes probarla con un monto pequeño y verificar en la app que quedó registrada como esperabas (entrada vs salida). Requiere confirm=true.",
  {
    confirm: z.boolean(),
    cashRegisterUuid: z.string().min(1),
    amount: z.string().describe("Monto como string decimal, ej. '150.00'"),
    comment: z.string().optional().default(""),
    paymentId: z.number().optional().default(1).describe("1=CASH,2=DEBIT_CARD,3=CREDIT_CARD,4=ELECTRONIC_TRANSFER,5=CHECK,6=GROCERY_VOUCHER"),
    type: z.union([z.string(), z.number()]).describe("⚠️ Valor NO confirmado para INCOME vs EXPENSE — prueba con cuidado, ver advertencia de la herramienta"),
  },
  async ({ confirm, cashRegisterUuid, amount, comment, paymentId, type }) => {
    if (!confirm) {
      return errorResult(new Error("confirm debe ser true. Lee la advertencia sobre el campo 'type' antes de usar con dinero real."));
    }
    try {
      const res = await apiClient.post(`${CASH_REGISTER_URL}/cashRegister/transaction`, {
        uuid: crypto.randomUUID(),
        cashRegisterUuid,
        amount,
        comment,
        paymentId: String(paymentId),
        type,
      });
      return textResult(res.data);
    } catch (err) {
      return errorResult(err);
    }
  }
);

server.tool(
  "sicarx_cash_register_unlock",
  "Desbloquea una caja registradora (POST cashregister/v1/cashRegister/unlock, body = uuid crudo como texto plano). Requiere confirm=true.",
  {
    confirm: z.boolean(),
    cashRegisterUuid: z.string().min(1),
  },
  async ({ confirm, cashRegisterUuid }) => {
    if (!confirm) {
      return errorResult(new Error("confirm debe ser true."));
    }
    try {
      const res = await apiClient.post(`${CASH_REGISTER_URL}/cashRegister/unlock`, cashRegisterUuid, {
        headers: { "Content-Type": "text/plain" },
      });
      return textResult(res.data);
    } catch (err) {
      return errorResult(err);
    }
  }
);

server.tool(
  "sicarx_close_cash_register",
  "Cierra/hace el corte de una caja registradora (POST cashregister/v1/cashRegister/close). ⚠️ Requiere 'lockUuid', un valor que la app normalmente saca de un candado local (localStorage) que este servidor MCP no tiene — probablemente haya que obtenerlo bloqueando la caja desde la app primero, o investigar más antes de confiar en este flujo para un corte de caja real. 'counted' es un objeto {\"<isoMoneda>.<paymentOptionId>\": \"<monto>\"} con los montos contados por forma de pago. Requiere confirm=true.",
  {
    confirm: z.boolean(),
    cashRegisterUuid: z.string().min(1),
    lockUuid: z.string().min(1).describe("⚠️ De dónde sacar esto no está confirmado — ver advertencia de la herramienta"),
    counted: z.record(z.string()).describe('Objeto {"<isoMoneda>.<paymentOptionId>": "<monto>"}, ej. {"MXN.1": "1500.00"}'),
    comment: z.string().optional(),
  },
  async ({ confirm, cashRegisterUuid, lockUuid, counted, comment }) => {
    if (!confirm) {
      return errorResult(new Error("confirm debe ser true. Lee la advertencia sobre 'lockUuid' antes de usar para un corte real."));
    }
    try {
      const body = { lockUuid, counted, cashRegisterUuid, ...(comment ? { comment } : {}) };
      const res = await apiClient.post(`${CASH_REGISTER_URL}/cashRegister/close`, body);
      return textResult(res.data);
    } catch (err) {
      return errorResult(err);
    }
  }
);

server.tool(
  "sicarx_create_payment_option",
  "Da de alta una forma de pago nueva (POST settings/v1/paymentOption). Requiere confirm=true.",
  {
    confirm: z.boolean(),
    fields: z.record(z.any()).describe("Objeto de la forma de pago, ver sicarx_get_payment_options para el shape de las existentes"),
  },
  async ({ confirm, fields }) => {
    if (!confirm) {
      return errorResult(new Error("confirm debe ser true."));
    }
    try {
      const res = await apiClient.post(`${SETTINGS_URL}/paymentOption`, fields);
      return textResult(res.data);
    } catch (err) {
      return errorResult(err);
    }
  }
);

server.tool(
  "sicarx_edit_payment_option",
  "Edita una forma de pago existente (PATCH settings/v1/paymentOption/{paymentOptionId}). Requiere confirm=true.",
  {
    confirm: z.boolean(),
    paymentOptionId: z.union([z.string(), z.number()]),
    fields: z.record(z.any()),
  },
  async ({ confirm, paymentOptionId, fields }) => {
    if (!confirm) {
      return errorResult(new Error("confirm debe ser true."));
    }
    try {
      const res = await apiClient.patch(`${SETTINGS_URL}/paymentOption/${encodeURIComponent(paymentOptionId)}`, fields);
      return textResult(res.data);
    } catch (err) {
      return errorResult(err);
    }
  }
);

server.tool(
  "sicarx_raw_request",
  "Escape hatch de propósito general: hace una petición HTTP directa a la API de SICAR-X (https://api.sicarx.com/) con el token de sesión adecuado. Útil para cualquier endpoint que no tenga una herramienta dedicada todavía. 'path' debe empezar con '/' y ser relativo a la base (ej. '/product/v1/product' o '/graph/v1/'). Para endpoints tipo GraphQL usa method='POST', path='/graph/v1/' (o el que corresponda) y body con {query: '...'} — revisa el código fuente de la app si necesitas la forma exacta de una query.",
  {
    method: z.enum(["GET", "POST", "PUT", "PATCH", "DELETE"]).default("GET"),
    path: z.string().min(1),
    query: z.record(z.any()).optional(),
    body: z.any().optional(),
    authLevel: z.enum(["company", "account", "none"]).default("company"),
    headers: z.record(z.string()).optional(),
  },
  async ({ method, path: reqPath, query, body, authLevel, headers }) => {
    try {
      const qs = query ? toQueryString(query) : "";
      const url = `${reqPath}${qs ? `?${qs}` : ""}`;
      const res = await apiClient.request({
        method,
        url,
        data: body,
        headers,
        __authLevel: authLevel,
      });
      return textResult({ status: res.status, data: res.data });
    } catch (err) {
      return errorResult(err);
    }
  }
);

// ---------------------------------------------------------------------------
// Herramientas deshabilitadas — confirmado en vivo el 2026-09-02 que
// sales-queries/v1 y purchases-queries/v1 devuelven 503 de gateway de forma
// consistente para esta cuenta (ver API.md, sección 3). En vez de dejarlas
// visibles fallando siempre, quedan registradas pero deshabilitadas: no
// aparecen en la lista de herramientas ni se pueden invocar ("Tool X
// disabled") hasta que se confirme que SICAR-X arregló el gateway. La
// alternativa que sí funciona es sicarx_report(report:'sales'|'purchases',
// variant:'data'). Para reactivarlas si algún día responden bien, comenta o
// borra este bloque (y de paso confirma con sicarx_raw_request antes).
// ---------------------------------------------------------------------------
for (const t of [toolListSales, toolGetSale, toolListPurchases, toolGetPurchase]) {
  t.disable();
}

// ---------------------------------------------------------------------------
// Transporte: por default stdio (proceso local, ej. Claude Desktop en la
// Mac). Si MCP_TRANSPORT=http, corre como servidor HTTP standalone (pensado
// para hospedarlo en un servidor propio vía cPanel "Setup Node.js App" u
// otro host Node.js) usando el transporte Streamable HTTP del SDK — así deja
// de depender de que la Mac esté prendida/vinculada. En modo http es
// OBLIGATORIO fijar MCP_HTTP_TOKEN (un secreto propio, no relacionado con
// SICAR-X) — el servidor se niega a arrancar sin él, para no exponer sin
// querer la cuenta real de SICAR-X a cualquiera que encuentre la URL.
// ---------------------------------------------------------------------------

async function mainStdio() {
  const transport = new StdioServerTransport();
  await server.connect(transport);
  console.error("sicarx-mcp: servidor MCP escuchando por stdio");
}

async function mainHttp() {
  const token = process.env.MCP_HTTP_TOKEN;
  if (!token) {
    throw new Error(
      "MCP_TRANSPORT=http requiere MCP_HTTP_TOKEN (un secreto propio para proteger el servidor). Defínelo como variable de entorno antes de arrancar."
    );
  }
  const port = Number(process.env.PORT) || 3000;

  // Un solo StreamableHTTPServerTransport, en modo stateful (genera un
  // sessionId por cliente conectado) compartido por todas las requests —
  // es el patrón recomendado por el SDK para un server HTTP de un solo
  // proceso.
  const transport = new StreamableHTTPServerTransport({
    sessionIdGenerator: () => crypto.randomUUID(),
  });
  await server.connect(transport);

  const httpServer = http.createServer(async (req, res) => {
    // CORS básico — el cliente real de Claude llama server-a-server, no
    // desde un navegador, pero no cuesta nada dejarlo abierto para pruebas.
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, DELETE, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization, Mcp-Session-Id, Mcp-Protocol-Version");
    if (req.method === "OPTIONS") {
      res.writeHead(204);
      res.end();
      return;
    }

    // Health check simple y sin autenticación, para confirmar que el
    // proceso está vivo (no expone nada sensible).
    if (req.method === "GET" && (req.url === "/" || req.url === "/health")) {
      res.writeHead(200, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ ok: true, service: "sicarx-mcp" }));
      return;
    }

    // Todo lo demás requiere el bearer token propio del servidor.
    const authHeader = req.headers.authorization || "";
    const expected = `Bearer ${token}`;
    if (authHeader !== expected) {
      res.writeHead(401, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ error: "unauthorized" }));
      return;
    }

    try {
      await transport.handleRequest(req, res);
    } catch (err) {
      console.error("sicarx-mcp: error manejando request HTTP", err);
      if (!res.headersSent) {
        res.writeHead(500, { "Content-Type": "application/json" });
        res.end(JSON.stringify({ error: "internal_error" }));
      }
    }
  });

  httpServer.listen(port, () => {
    console.error(`sicarx-mcp: servidor MCP escuchando por HTTP en el puerto ${port}`);
  });
}

function main() {
  if ((process.env.MCP_TRANSPORT || "stdio").toLowerCase() === "http") {
    return mainHttp();
  }
  return mainStdio();
}

main().catch((err) => {
  console.error("sicarx-mcp: error fatal al iniciar", err);
  process.exit(1);
});
